<?php
declare(strict_types=1);

/* =====================================================
   DATABASE CONFIG — change these to match your server
===================================================== */
$dbHost = 'localhost';
$dbName = 'quiz_mobile';
$dbUser = 'root';        // your MySQL username
$dbPass = '';            // your MySQL password

/* =====================================================
   CONNECT + AUTO-CREATE TABLE
===================================================== */
try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS quiz_answers (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            food_category       VARCHAR(100)  DEFAULT NULL,
            food_dish           VARCHAR(255)  DEFAULT NULL,
            roti_type           VARCHAR(100)  DEFAULT NULL,
            street_food         VARCHAR(255)  DEFAULT NULL,
            homemade_food       VARCHAR(255)  DEFAULT NULL,
            custom_food         TEXT,
            icecream_company    VARCHAR(100)  DEFAULT NULL,
            icecream_flavor     VARCHAR(100)  DEFAULT NULL,
            comfortable         VARCHAR(255)  DEFAULT NULL,
            meeting_activities  TEXT,
            movie_category      VARCHAR(100)  DEFAULT NULL,
            garden_location     VARCHAR(150)  DEFAULT NULL,
            mall_choice         VARCHAR(150)  DEFAULT NULL,
            sport_choice        VARCHAR(150)  DEFAULT NULL,
            meeting_date        VARCHAR(20)   DEFAULT NULL,
            meeting_time        VARCHAR(20)   DEFAULT NULL,
            chess_won           TINYINT(1)    NOT NULL DEFAULT 0,
            chess_captures      INT           NOT NULL DEFAULT 0,
            chess_moves         INT           NOT NULL DEFAULT 0,
            created_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_created_at (created_at),
            INDEX idx_chess_won  (chess_won)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

} catch (Throwable $e) {
    $dbError = $e->getMessage();
}

/* =====================================================
   SAVE QUIZ (POST)
===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_quiz'])) {
    header('Content-Type: application/json');
    if (isset($dbError)) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $dbError]);
        exit;
    }
    try {
        $fields = ['food_category','food_dish','roti_type','street_food','homemade_food','custom_food',
                   'icecream_company','icecream_flavor','comfortable','meeting_activities','movie_category',
                   'garden_location','mall_choice','sport_choice','meeting_date','meeting_time',
                   'chess_won','chess_captures','chess_moves'];
        $data = [];
        foreach ($fields as $f) {
            $data[":$f"] = trim((string)($_POST[$f] ?? ''));
        }
        $stmt = $pdo->prepare("
            INSERT INTO quiz_answers (" . implode(',', $fields) . ")
            VALUES (" . implode(',', array_map(fn($f) => ":$f", $fields)) . ")
        ");
        $stmt->execute($data);
        echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

/* =====================================================
   VIEW ANSWERS (GET)
===================================================== */
if (isset($_GET['view_answers'])) {
    if (isset($dbError)) die('Database error: ' . htmlspecialchars($dbError));
    $rows = $pdo->query("SELECT * FROM quiz_answers ORDER BY id DESC")->fetchAll();
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Answers</title>";
    echo "<style>
        body{font-family:-apple-system,Arial;background:#0a0a14;color:#f0e8ff;padding:30px;margin:0}
        h1{background:linear-gradient(90deg,#d4b8e0,#c9a9b8,#e8c8d0);-webkit-background-clip:text;background-clip:text;color:transparent;font-size:32px;margin-bottom:20px}
        .wrap{overflow-x:auto;border-radius:20px;box-shadow:0 20px 60px rgba(212,184,224,.15)}
        table{width:100%;border-collapse:collapse;background:#15151f;min-width:1400px}
        th,td{padding:12px 14px;border-bottom:1px solid rgba(212,184,224,.08);text-align:left;font-size:13px;white-space:nowrap}
        th{background:#1e1e2e;color:#d4b8e0;position:sticky;top:0;font-weight:700;letter-spacing:.5px;text-transform:uppercase;font-size:11px}
        tr:hover{background:#1a1a28}
        tr:last-child td{border-bottom:none}
        .win{color:#7dff9c;font-weight:700}
        .lose{color:#ff6f6f}
        .empty{text-align:center;padding:60px;color:#666;font-size:16px}
    </style></head><body>";
    echo "<h1>💛 Quiz Answers (" . count($rows) . ")</h1>";
    if (empty($rows)) {
        echo "<div class='empty'>No answers yet — go complete the quiz! 💛</div>";
    } else {
        echo "<div class='wrap'><table><thead><tr>";
        foreach (array_keys($rows[0]) as $c) echo "<th>" . htmlspecialchars($c) . "</th>";
        echo "</tr></thead><tbody>";
        foreach ($rows as $row) {
            echo "<tr>";
            foreach ($row as $k => $v) {
                $cls = '';
                if ($k === 'chess_won') {
                    $cls = ((int)$v === 1) ? 'win' : 'lose';
                    $v = ((int)$v === 1) ? '✅ Yes' : '❌ No';
                }
                echo "<td class='$cls'>" . htmlspecialchars((string)$v) . "</td>";
            }
            echo "</tr>";
        }
        echo "</tbody></table></div>";
    }
    echo "</body></html>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0a0a14">
<title>Our Little Quiz 💛</title>

<style>

/* =====================================================
   RESET & BASE
===================================================== */
* { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }

html, body {
    width: 100%;
    min-height: 100vh;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Arial, sans-serif;
    background: #05050c;
    color: #fff;
    user-select: none;
    overflow: hidden; /* Prevent body scroll, handled by app-content */
}

.iphone-stage {
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #05050c; /* Simplified background for performance */
    position: relative;
    overflow: hidden;
}

/* ===== SIMPLIFIED AURORA (Performance optimized) ===== */
.aurora {
    position: absolute;
    inset: 0;
    z-index: 0;
    opacity: 0.4;
    pointer-events: none;
    background: 
        radial-gradient(circle at 20% 30%, rgba(212, 184, 224, 0.2), transparent 40%),
        radial-gradient(circle at 80% 70%, rgba(201, 169, 184, 0.2), transparent 40%);
}

/* ===== FLOATING PARTICLES (Reduced count) ===== */
.particles {
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    overflow: hidden;
}

.particle {
    position: absolute;
    width: 3px; height: 3px;
    border-radius: 50%;
    background: #d4b8e0;
    box-shadow: 0 0 6px #d4b8e0;
    animation: floatUp linear infinite;
    opacity: 0;
}

@keyframes floatUp {
    0% { transform: translateY(100vh) scale(0); opacity: 0; }
    10% { opacity: 0.6; }
    90% { opacity: 0.6; }
    100% { transform: translateY(-10vh) scale(1); opacity: 0; }
}

/* ===== HELLO OVERLAY ===== */
.hello-overlay {
    position: fixed;
    inset: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    background: radial-gradient(circle at 50% 50%, #1a0a2a, #05050c);
    transition: opacity 1.2s ease, transform 1.2s ease;
}

.hello-overlay.hide {
    opacity: 0;
    transform: scale(1.1);
    pointer-events: none;
}

.hello-text {
    font-size: clamp(40px, 15vw, 100px);
    font-weight: 900;
    background: linear-gradient(90deg, #d4b8e0, #c9a9b8, #e8c8d0, #d4b8e0);
    background-size: 300% auto;
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    animation: helloShine 4s linear infinite, helloPop 2s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
    letter-spacing: -2px;
    text-align: center;
}

@keyframes helloShine {
    0% { background-position: 0% center; }
    100% { background-position: 300% center; }
}

@keyframes helloPop {
    0% { opacity: 0; transform: scale(0.5); }
    100% { opacity: 1; transform: scale(1); }
}

/* =====================================================
   IPHONE FRAME
===================================================== */
.iphone {
    position: relative;
    width: 393px;
    height: 852px;
    background: #000;
    border-radius: 55px;
    box-shadow:
        0 0 0 12px #1a1a1a,
        0 0 0 14px #0a0a0a,
        0 20px 60px rgba(0, 0, 0, 0.8);
    overflow: hidden;
    z-index: 1;
}

@media (max-width: 480px), (max-height: 900px) {
    .iphone {
        width: 100vw; height: 100vh;
        border-radius: 0;
        box-shadow: none;
    }
    .iphone::before, .iphone::after { display: none; }
    .screen { border-radius: 0; }
    .app-view { border-radius: 0; }
}

/* =====================================================
   SCREEN
===================================================== */
.screen {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 44px;
    overflow: hidden;
    background: #000;
    z-index: 2;
}

/* Status bar */
.status-bar {
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 54px;
    padding: 18px 32px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 15px;
    font-weight: 600;
    color: #fff;
    z-index: 100;
    pointer-events: none;
}

.status-bar .battery {
    width: 24px; height: 12px;
    border: 1.5px solid rgba(255,255,255,0.6);
    border-radius: 3px;
    position: relative;
    padding: 1.5px;
}

.status-bar .battery::after {
    content: "";
    position: absolute;
    right: -4px; top: 3px;
    width: 2px; height: 5px;
    background: rgba(255,255,255,0.6);
    border-radius: 0 1px 1px 0;
}

.status-bar .battery-fill {
    width: 82%; height: 100%;
    background: #7dff9c;
    border-radius: 1px;
}

/* Dynamic Island */
.dynamic-island {
    position: absolute;
    top: 11px; left: 50%;
    transform: translateX(-50%);
    width: 126px; height: 36px;
    background: #000;
    border-radius: 20px;
    z-index: 101;
    transition: all 0.5s cubic-bezier(.2,.9,.2,1);
    pointer-events: none;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.dynamic-island.expanded { width: 340px; height: 80px; border-radius: 40px; }

.dynamic-island-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 0 20px;
    opacity: 0;
    transition: opacity 0.3s;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
}

.dynamic-island.expanded .dynamic-island-content { opacity: 1; }

/* =====================================================
   LOCK SCREEN
===================================================== */
.lock-screen {
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #150a1a 40%, #1a0a15 100%);
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 90px;
    z-index: 50;
    transition: opacity 0.5s ease, transform 0.5s ease;
    overflow: hidden;
}

.lock-screen.hidden {
    opacity: 0;
    transform: translateY(-100%);
    pointer-events: none;
}

.lock-time {
    font-size: 82px;
    font-weight: 200;
    letter-spacing: -3px;
    color: #fff;
    line-height: 1;
}

.lock-date {
    font-size: 20px;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.8);
    margin-top: 8px;
}

.lock-notifications {
    width: 100%;
    padding: 0 16px;
    margin-top: 40px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.lock-notif {
    background: rgba(40, 40, 55, 0.85);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    opacity: 0;
    transform: translateY(-20px);
    animation: notifSlideIn 0.5s cubic-bezier(.2,.9,.2,1) forwards;
    cursor: pointer;
}

@keyframes notifSlideIn {
    to { opacity: 1; transform: translateY(0); }
}

.lock-notif-icon {
    width: 40px; height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    flex-shrink: 0;
}

.lock-notif-icon.messages { background: #34c759; }
.lock-notif-icon.heart { background: #ff2e63; }
.lock-notif-icon.music { background: #fc5c7d; }
.lock-notif-icon.whatsapp { background: #25d366; }
.lock-notif-icon.instagram { background: linear-gradient(135deg, #f09433, #dc2743, #bc1888); }
.lock-notif-icon.snapchat { background: #fffc00; color: #000; }
.lock-notif-icon.health { background: #ff6b9d; }

.lock-notif-content { flex: 1; min-width: 0; }
.lock-notif-title { font-size: 14px; font-weight: 600; color: #fff; margin-bottom: 2px; }
.lock-notif-body { font-size: 13px; color: rgba(255, 255, 255, 0.75); line-height: 1.35; }
.lock-notif-time { font-size: 11px; color: rgba(255, 255, 255, 0.5); margin-top: 4px; }

.lock-bottom {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    padding: 20px 40px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.lock-bottom-icon {
    width: 50px; height: 50px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    cursor: pointer;
    color: #fff;
    transition: transform 0.2s;
}

.lock-bottom-icon:active { transform: scale(0.9); }

.swipe-hint {
    position: absolute;
    bottom: 110px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 13px;
    color: rgba(255, 255, 255, 0.4);
    animation: swipeHint 2.5s ease-in-out infinite;
    text-align: center;
}

@keyframes swipeHint {
    0%, 100% { transform: translateX(-50%) translateY(0); opacity: 0.4; }
    50% { transform: translateX(-50%) translateY(-10px); opacity: 0.9; }
}

.home-bar {
    position: absolute;
    bottom: 8px; left: 50%;
    transform: translateX(-50%);
    width: 140px; height: 5px;
    background: rgba(255, 255, 255, 0.4);
    border-radius: 3px;
    z-index: 200;
    cursor: pointer;
    transition: transform 0.2s;
}

.home-bar:active { transform: translateX(-50%) scaleX(1.1); background: rgba(255, 255, 255, 0.8); }

/* =====================================================
   HOME SCREEN
===================================================== */
.home-screen {
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, #0a0a1a 0%, #150a1a 40%, #1a0a15 100%);
    display: flex;
    flex-direction: column;
    padding: 70px 24px 40px;
    z-index: 40;
    opacity: 0;
    transform: scale(1.05);
    pointer-events: none;
    transition: opacity 0.4s ease, transform 0.4s ease;
}

.home-screen.active { opacity: 1; transform: scale(1); pointer-events: auto; }

.app-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 22px 16px;
    margin-top: 20px;
}

.app-icon {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    opacity: 0;
    transform: translateY(10px);
    animation: appEnter 0.4s cubic-bezier(.2,.9,.2,1) forwards;
}

@keyframes appEnter {
    to { opacity: 1; transform: translateY(0); }
}

.app-icon:nth-child(1) { animation-delay: 0.05s; }
.app-icon:nth-child(2) { animation-delay: 0.10s; }
.app-icon:nth-child(3) { animation-delay: 0.15s; }
.app-icon:nth-child(4) { animation-delay: 0.20s; }
.app-icon:nth-child(5) { animation-delay: 0.25s; }
.app-icon:nth-child(6) { animation-delay: 0.30s; }
.app-icon:nth-child(7) { animation-delay: 0.35s; }
.app-icon:nth-child(8) { animation-delay: 0.40s; }

.app-icon:active { transform: scale(0.9); transition: transform 0.1s; }

.app-icon .icon {
    width: 62px; height: 62px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    position: relative;
}

.app-icon .icon::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.25), transparent 50%);
    pointer-events: none;
    border-radius: 18px;
}

.app-icon .icon.messages { background: #34c759; }
.app-icon .icon.quiz { background: #ffb800; }
.app-icon .icon.photos { background: #ff2e97; }
.app-icon .icon.camera { background: #4a4a5a; }
.app-icon .icon.music { background: #f857a6; }
.app-icon .icon.settings { background: #6a6a7a; }
.app-icon .icon.maps { background: #34c759; }
.app-icon .icon.weather { background: #1976d2; }
.app-icon .icon.calendar { background: #fff; color: #ff3b30; }
.app-icon .icon.notes { background: #f9a825; }
.app-icon .icon.mail { background: #1976d2; }
.app-icon .icon.health { background: #e91e63; }
.app-icon .icon.whatsapp { background: #25d366; }
.app-icon .icon.instagram { background: linear-gradient(45deg, #f09433, #dc2743, #bc1888); }
.app-icon .icon.snapchat { background: #fffc00; color: #000; }

.app-icon .label {
    font-size: 11px;
    color: #fff;
    text-align: center;
    font-weight: 500;
    text-shadow: 0 1px 3px rgba(0,0,0,0.5);
}

.app-icon .badge {
    position: absolute;
    top: -4px; right: -4px;
    min-width: 22px; height: 22px;
    background: #ff3b30;
    color: #fff;
    border-radius: 11px;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 5px;
    border: 2px solid rgba(0,0,0,0.1);
    z-index: 2;
}

.dock {
    margin-top: auto;
    background: rgba(40, 40, 55, 0.6);
    border-radius: 30px;
    padding: 14px 18px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    gap: 16px;
    border: 1px solid rgba(255, 255, 255, 0.08);
}

.dock .app-icon .label { display: none; }
.dock .app-icon .icon { width: 58px; height: 58px; font-size: 30px; }

.page-dots {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 14px;
}

.page-dots .dot { width: 7px; height: 7px; border-radius: 50%; background: rgba(255, 255, 255, 0.3); transition: all 0.3s; }
.page-dots .dot.active { background: #d4b8e0; }

/* =====================================================
   CONTROL CENTER
===================================================== */
.control-center {
    position: absolute;
    inset: 0;
    background: rgba(15, 15, 22, 0.95);
    z-index: 80;
    padding: 70px 16px 30px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    transform: translateY(-100%);
    transition: transform 0.4s cubic-bezier(.2,.9,.2,1), opacity 0.3s;
    opacity: 0;
    pointer-events: none;
    overflow-y: auto;
}

.control-center.active { transform: translateY(0); opacity: 1; pointer-events: auto; }

.cc-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 8px;
    margin-bottom: 4px;
}

.cc-header h3 { font-size: 17px; font-weight: 600; color: #fff; }

.cc-close {
    background: rgba(120, 120, 128, 0.32);
    border: none;
    color: #fff;
    width: 30px; height: 30px;
    border-radius: 50%;
    font-size: 14px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.cc-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.cc-tile {
    background: rgba(40, 40, 55, 0.6);
    border-radius: 22px;
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    border: 1px solid rgba(255, 255, 255, 0.06);
}

.cc-tile.wide { grid-column: span 2; }

.cc-tile-title {
    font-size: 11px;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.5);
    text-transform: uppercase;
    letter-spacing: 1.2px;
}

.cc-tile-row { display: flex; gap: 12px; align-items: center; }

.cc-toggle-btn {
    width: 52px; height: 52px;
    border-radius: 50%;
    background: rgba(120, 120, 128, 0.32);
    border: none;
    color: #fff;
    font-size: 22px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;
}

.cc-toggle-btn.on { background: #34c759; }
.cc-toggle-btn:active { transform: scale(0.9); }

.cc-slider-row { display: flex; align-items: center; gap: 10px; }
.cc-slider-row input[type="range"] { flex: 1; height: 32px; border-radius: 16px; }
.cc-slider-row .slider-icon { font-size: 16px; color: rgba(255, 255, 255, 0.6); width: 20px; text-align: center; }

.cc-music { display: flex; align-items: center; gap: 12px; }
.cc-music-art { width: 54px; height: 54px; border-radius: 12px; background: #d4b8e0; display: flex; align-items: center; justify-content: center; font-size: 26px; }
.cc-music-info { flex: 1; min-width: 0; }
.cc-music-title { font-size: 14px; font-weight: 600; color: #fff; }
.cc-music-artist { font-size: 12px; color: rgba(255, 255, 255, 0.5); margin-top: 2px; }
.cc-music-controls { display: flex; gap: 6px; }
.cc-music-controls button { background: none; border: none; color: #fff; font-size: 22px; cursor: pointer; }

.cc-permissions {
    background: rgba(40, 40, 55, 0.6);
    border-radius: 22px;
    padding: 14px 16px;
    margin-top: 4px;
}

.cc-permissions h4 {
    font-size: 13px;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.6);
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.permission-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}

.permission-row:last-child { border-bottom: none; }
.permission-info { display: flex; align-items: center; gap: 12px; flex: 1; }
.permission-icon { width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; background: rgba(120, 120, 128, 0.25); }
.permission-text { font-size: 15px; color: #fff; }

.ios-toggle {
    position: relative;
    width: 51px; height: 31px;
    background: rgba(120, 120, 128, 0.32);
    border-radius: 16px;
    cursor: pointer;
    transition: background 0.3s;
    border: none;
}

.ios-toggle.on { background: #34c759; }
.ios-toggle::after {
    content: "";
    position: absolute;
    top: 2px; left: 2px;
    width: 27px; height: 27px;
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    transition: transform 0.3s cubic-bezier(.2,.9,.2,1);
}
.ios-toggle.on::after { transform: translateX(20px); }

/* =====================================================
   APP VIEW
===================================================== */
.app-view {
    position: absolute;
    inset: 0;
    background: #000;
    z-index: 60;
    transform: translateY(100%);
    transition: transform 0.4s cubic-bezier(.2,.9,.2,1);
    overflow: hidden;
    border-radius: 44px;
    display: flex;
    flex-direction: column;
}

.app-view.active { transform: translateY(0); }

.app-top-bar {
    background: #14141e;
    padding: 60px 18px 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    flex-shrink: 0;
    z-index: 2;
}

.app-back-btn {
    background: none;
    border: none;
    color: #d4b8e0;
    font-size: 15px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 4px;
    cursor: pointer;
    padding: 6px;
}

.app-title { font-size: 16px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px; }
.app-title-avatar { width: 30px; height: 30px; border-radius: 50%; background: #d4b8e0; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #2a1a2a; font-weight: 900;}
.app-more-btn { background: none; border: none; color: #d4b8e0; font-size: 20px; cursor: pointer; padding: 6px; }

.app-content {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 40px;
    background: #0a0a1a;
    color: #f0e8ff;
    scrollbar-width: none;
}

.app-content::-webkit-scrollbar { display: none; }

/* =====================================================
   NOTIFICATION BANNER
===================================================== */
.notif-banner {
    position: absolute;
    top: 12px; left: 12px; right: 12px;
    background: rgba(40, 40, 55, 0.95);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 12px 14px;
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 500;
    transform: translateY(-150%);
    transition: transform 0.4s cubic-bezier(.2,.9,.2,1);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    cursor: pointer;
}

.notif-banner.show { transform: translateY(0); }

.notif-banner-icon {
    width: 40px; height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    flex-shrink: 0;
    background: #34c759;
}

.notif-banner-content { flex: 1; min-width: 0; }
.notif-banner-title { font-size: 13px; font-weight: 700; color: #fff; margin-bottom: 2px; }
.notif-banner-body { font-size: 12px; color: rgba(255, 255, 255, 0.75); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.notif-banner-time { font-size: 10px; color: rgba(255, 255, 255, 0.4); flex-shrink: 0; }

/* =====================================================
   QUIZ CONTENT
===================================================== */
.quiz-header { text-align: center; padding: 20px 18px 12px; }
.quiz-header .small-title { font-size: 10px; letter-spacing: 4px; text-transform: uppercase; color: #d4b8e0; margin-bottom: 8px; font-weight: 700; }
.quiz-header h1 {
    font-size: 24px;
    background: linear-gradient(90deg, #d4b8e0, #c9a9b8, #e8c8d0, #d4b8e0);
    background-size: 300% auto;
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    font-weight: 900;
    letter-spacing: 0.5px;
}

.quiz-progress { padding: 0 18px; margin: 10px 0 16px; }
.quiz-progress-top { display: flex; justify-content: space-between; font-size: 10px; color: rgba(255, 255, 255, 0.4); margin-bottom: 6px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; }
.quiz-progress-bar { height: 6px; background: rgba(120, 120, 128, 0.3); border: 1px solid rgba(212, 184, 224, 0.15); border-radius: 50px; overflow: hidden; }
.quiz-progress-fill {
    width: 0%;
    height: 100%;
    border-radius: 50px;
    background: linear-gradient(90deg, #d4b8e0, #c9a9b8, #e8c8d0);
    transition: width 0.5s ease-out;
}

.quiz-screen { display: none; padding: 0 16px; }
.quiz-screen.active { display: block; animation: screenIn 0.4s ease-out; }

@keyframes screenIn {
    from { opacity: 0; transform: translateY(15px); }
    to { opacity: 1; transform: translateY(0); }
}

.quiz-question-title { text-align: center; font-size: 18px; margin: 8px 0 14px; color: #fff; font-weight: 800; }
.quiz-question-sub { text-align: center; color: rgba(255, 255, 255, 0.5); font-size: 12px; margin-bottom: 16px; }

.quiz-hero { text-align: center; padding: 25px 10px 15px; }
.quiz-hero .hero-emoji { font-size: 60px; display: inline-block; }
.quiz-hero h2 { font-size: 20px; margin: 14px 0; color: #fff; font-weight: 800; line-height: 1.3; }
.quiz-hero p { color: rgba(255, 255, 255, 0.55); line-height: 1.6; font-size: 13px; }

.quiz-buttons { display: flex; flex-direction: column; gap: 10px; margin-top: 20px; }
.quiz-btn {
    padding: 14px 20px;
    border-radius: 50px;
    font-weight: 800;
    letter-spacing: 1px;
    text-transform: uppercase;
    font-size: 12px;
    border: none;
    cursor: pointer;
    transition: transform 0.15s, box-shadow 0.15s;
}

.quiz-btn:active { transform: scale(0.96); }
.quiz-btn.primary { background: linear-gradient(135deg, #d4b8e0, #c9a9b8, #e8c8d0); color: #2a1a2a; box-shadow: 0 4px 15px rgba(212, 184, 224, 0.3); }
.quiz-btn.secondary { background: rgba(40, 40, 55, 0.8); color: #d4b8e0; border: 2px solid rgba(212, 184, 224, 0.3); }

/* Quiz option grids */
.quiz-option-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 14px; }
.quiz-option {
    position: relative;
    border-radius: 18px;
    overflow: hidden;
    background: rgba(40, 40, 55, 0.7);
    border: 2px solid rgba(212, 184, 224, 0.1);
    cursor: pointer;
    transition: border-color 0.2s, transform 0.2s;
}

.quiz-option:active { transform: scale(0.97); }
.quiz-option.selected { border-color: #d4b8e0; box-shadow: 0 0 15px rgba(212, 184, 224, 0.2); }

.quiz-option.selected::after {
    content: "✓";
    position: absolute;
    top: 8px; right: 8px;
    width: 26px; height: 26px;
    display: flex; align-items: center; justify-content: center;
    background: #d4b8e0;
    color: #2a1a2a;
    border-radius: 50%;
    font-size: 14px;
    font-weight: bold;
    z-index: 2;
}

.quiz-option img { width: 100%; height: 90px; object-fit: cover; display: block; }
.quiz-option-label { padding: 10px 8px 12px; text-align: center; font-size: 11px; font-weight: 700; color: #fff; }
.quiz-option-grid.single { grid-template-columns: 1fr; }
.quiz-option-grid.single .quiz-option img { height: 110px; }

.quiz-subdetail {
    display: none;
    margin-top: 16px;
    padding: 16px;
    background: rgba(30, 30, 45, 0.7);
    border: 1px solid rgba(212, 184, 224, 0.15);
    border-radius: 20px;
}

.quiz-subdetail.active { display: block; }

.quiz-subdetail-title { font-size: 13px; font-weight: 800; color: #d4b8e0; text-align: center; margin-bottom: 10px; }
.quiz-subdetail-sub { font-size: 11px; color: rgba(255, 255, 255, 0.4); text-align: center; margin-bottom: 12px; }

.quiz-dish-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.quiz-dish {
    position: relative;
    border-radius: 14px;
    overflow: hidden;
    background: rgba(40, 40, 55, 0.8);
    border: 2px solid rgba(212, 184, 224, 0.1);
    cursor: pointer;
}

.quiz-dish:active { transform: scale(0.95); }
.quiz-dish.selected { border-color: #d4b8e0; box-shadow: 0 0 10px rgba(212, 184, 224, 0.2); }
.quiz-dish.selected::after {
    content: "✓";
    position: absolute;
    top: 6px; right: 6px;
    width: 22px; height: 22px;
    display: flex; align-items: center; justify-content: center;
    background: #d4b8e0;
    color: #2a1a2a;
    border-radius: 50%;
    font-size: 12px;
    font-weight: bold;
    z-index: 2;
}

.quiz-dish img { width: 100%; height: 60px; object-fit: cover; display: block; }
.quiz-dish-label { padding: 7px; text-align: center; font-size: 10px; font-weight: 700; color: #fff; line-height: 1.2; }

.quiz-field { margin-bottom: 14px; }
.quiz-field label { display: block; font-size: 11px; font-weight: 800; margin-bottom: 6px; color: #d4b8e0; letter-spacing: 1.5px; text-transform: uppercase; }
.quiz-field input, .quiz-field select, .quiz-field textarea {
    width: 100%;
    padding: 14px 16px;
    border: 1.5px solid rgba(212, 184, 224, 0.2);
    outline: none;
    border-radius: 14px;
    background: rgba(30, 30, 45, 0.8);
    font: inherit;
    color: #fff;
    font-size: 14px;
}

.quiz-field textarea { min-height: 90px; resize: vertical; }
.quiz-field input:focus, .quiz-field select:focus, .quiz-field textarea:focus { border-color: #d4b8e0; }

/* =====================================================
   CHESS (Optimized for performance & smooth animations)
===================================================== */
.chess-section { text-align: center; padding: 10px 4px; }

.chess-badge {
    display: inline-flex;
    padding: 8px 22px;
    margin-bottom: 14px;
    border-radius: 999px;
    background: #1a1a2e;
    border: 1.5px solid rgba(212, 184, 224, 0.3);
    color: #d4b8e0;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 3px;
    text-transform: uppercase;
}

.chess-status {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin: 12px auto;
    padding: 12px 20px;
    border-radius: 18px;
    background: rgba(30, 30, 45, 0.8);
    border: 1px solid rgba(212, 184, 224, 0.2);
    text-align: left;
    max-width: 320px;
}

.chess-status-icon {
    width: 44px; height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 14px;
    background: rgba(212, 184, 224, 0.1);
    border: 1px solid rgba(212, 184, 224, 0.15);
    font-size: 24px;
}

.chess-status-text strong { display: block; color: #fff; font-size: 13px; font-weight: 700; }
.chess-status-text span { display: block; margin-top: 3px; color: rgba(255, 255, 255, 0.45); font-size: 11px; }

.chess-board-wrapper {
    position: relative;
    width: min(88vw, 340px);
    margin: 16px auto;
    border-radius: 20px;
    padding: 12px;
    background: #1a1a2e;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    border: 2px solid rgba(212, 184, 224, 0.1);
}

.chess-board {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    aspect-ratio: 1;
    border-radius: 10px;
    overflow: hidden;
    position: relative;
    background: #b8a8a0; /* Fallback */
}

.chess-square {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: clamp(20px, 6vw, 36px);
    cursor: pointer;
    aspect-ratio: 1;
    line-height: 1;
}

.chess-square.light { background: #b8a8a0; color: #2a1a2a; }
.chess-square.dark { background: #6a5a5a; color: #f0e8e0; }

.chess-square.selected { background: rgba(212, 184, 224, 0.5) !important; }
.chess-square.valid-move::after {
    content: '';
    position: absolute;
    width: 30%; height: 30%;
    border-radius: 50%;
    background: rgba(212, 184, 224, 0.6);
    pointer-events: none;
}
.chess-square.valid-move.capture::after {
    width: 85%; height: 85%;
    background: transparent;
    border: 3px solid rgba(255, 70, 70, 0.7);
    border-radius: 10px;
}

.chess-square.last-move { background: rgba(212, 184, 224, 0.3) !important; }

.chess-square .piece {
    transition: transform 0.2s ease-out; /* Smooth animation */
    pointer-events: none;
    z-index: 2;
}

.chess-square .piece.moving {
    transform: scale(1.2);
    z-index: 10;
}

.chess-result {
    margin: 14px auto 0;
    padding: 20px;
    border-radius: 20px;
    background: rgba(30, 30, 45, 0.8);
    border: 2px solid rgba(212, 184, 224, 0.15);
    max-width: 340px;
}

.chess-result.win { border-color: rgba(212, 184, 224, 0.6); box-shadow: 0 0 30px rgba(212, 184, 224, 0.2); }
.chess-result-icon { font-size: 36px; margin-bottom: 10px; }
.chess-result h3 { color: #fff; font-size: 15px; font-weight: 800; margin-bottom: 6px; }
.chess-result p { color: rgba(255, 255, 255, 0.5); font-size: 12px; line-height: 1.6; }
.chess-result .highlight-text { color: #d4b8e0; font-weight: 800; }

.chess-progress-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    margin: 10px auto;
    max-width: 320px;
    border-radius: 14px;
    background: rgba(30, 30, 45, 0.7);
    border: 1px solid rgba(212, 184, 224, 0.15);
    color: #d4b8e0;
    font-weight: 800;
    font-size: 11px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.chess-message {
    max-width: 320px;
    margin: 0 auto 12px;
    padding: 12px 16px;
    border-radius: 14px;
    background: rgba(212, 184, 224, 0.06);
    border: 1px solid rgba(212, 184, 224, 0.15);
    color: rgba(255, 255, 255, 0.5);
    font-size: 11px;
    font-weight: 700;
    text-align: center;
}

.chess-message.ready { background: rgba(212, 184, 224, 0.12); border-color: rgba(212, 184, 224, 0.4); color: #d4b8e0; }
.chess-message.check { background: rgba(255, 70, 70, 0.1); border-color: rgba(255, 70, 70, 0.3); color: #ff6f6f; }

.chess-captured { display: flex; justify-content: center; gap: 4px; flex-wrap: wrap; min-height: 24px; margin: 6px 0; font-size: 18px; opacity: 0.7; }
.chess-captured span { animation: piecePop 0.3s ease-out; }

@keyframes piecePop { 0% { transform: scale(0); } 100% { transform: scale(1); } }

.meeting-unlocked {
    display: none;
    margin: 16px auto;
    padding: 24px;
    max-width: 340px;
    border-radius: 22px;
    background: linear-gradient(135deg, rgba(212, 184, 224, 0.1), rgba(201, 169, 184, 0.1));
    border: 2px solid rgba(212, 184, 224, 0.4);
    box-shadow: 0 0 30px rgba(212, 184, 224, 0.2);
}

.meeting-unlocked.show { display: block; animation: unlockReveal 0.5s ease-out; }
@keyframes unlockReveal { 0% { transform: scale(0.9); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }

.meeting-unlocked h3 { color: #d4b8e0; font-size: 20px; font-weight: 900; margin-bottom: 10px; }
.meeting-unlocked p { color: #fff; font-size: 14px; font-weight: 600; line-height: 1.6; }
.meeting-unlocked .big-emoji { font-size: 55px; margin: 10px 0; }
.meeting-unlocked .sub-text { color: #d4b8e0; font-size: 13px; font-weight: 800; }

/* =====================================================
   OTHER SCREENS
===================================================== */
.friendship-card { text-align: center; padding: 20px 10px; }
.friendship-heart { font-size: 60px; display: inline-block; }
.friendship-level { font-size: 40px; font-weight: 900; background: linear-gradient(90deg, #d4b8e0, #c9a9b8, #e8c8d0, #d4b8e0); -webkit-background-clip: text; background-clip: text; color: transparent; margin: 10px 0; }
.friendship-bar { height: 12px; background: rgba(120, 120, 128, 0.3); border: 1px solid rgba(212, 184, 224, 0.15); border-radius: 50px; overflow: hidden; margin: 12px auto; max-width: 250px; }
.friendship-fill { height: 100%; width: 0; background: linear-gradient(90deg, #d4b8e0, #c9a9b8, #e8c8d0); transition: width 1.5s ease-out; }

.meeting-card { margin: 16px 0 0; padding: 16px; border-radius: 18px; background: rgba(212, 184, 224, 0.08); border: 1px solid rgba(212, 184, 224, 0.2); text-align: left; }
.meeting-card h3 { font-size: 13px; color: #d4b8e0; margin-bottom: 8px; }
.meeting-card p { font-size: 12px; color: #fff; margin: 4px 0; line-height: 1.6; }

.surprise-box { text-align: center; padding: 25px 10px; }
.surprise-icon { font-size: 70px; margin-bottom: 16px; cursor: pointer; display: inline-block; }
.win-banner { display: inline-block; margin: 8px auto 16px; padding: 12px 26px; background: linear-gradient(135deg, #d4b8e0, #c9a9b8, #e8c8d0); color: #2a1a2a; border-radius: 50px; font-size: 14px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; }
.surprise-content { display: none; margin-top: 16px; padding: 24px; border-radius: 22px; background: rgba(212, 184, 224, 0.1); border: 2px solid rgba(212, 184, 224, 0.3); }
.surprise-content.show { display: block; animation: revealContent 0.4s ease-out; }
@keyframes revealContent { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }

.contact-buttons { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; }
.contact-btn { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 20px; border-radius: 50px; font-weight: 800; font-size: 12px; text-decoration: none; text-transform: uppercase; letter-spacing: 1px; }
.contact-btn:active { transform: scale(0.96); }
.contact-btn.call { background: #d4b8e0; color: #2a1a2a; }
.contact-btn.msg { background: #e8c8d0; color: #2a1a2a; }
.contact-btn.wa { background: #34c759; color: #0a2a0a; }

.phone-display { display: inline-block; padding: 12px 24px; margin: 10px 0; background: rgba(30, 30, 45, 0.8); border: 1.5px solid rgba(212, 184, 224, 0.3); border-radius: 50px; font-size: 14px; font-weight: 900; color: #d4b8e0; }

.toast {
    position: absolute;
    left: 50%;
    bottom: 30px;
    transform: translate(-50%, 20px);
    background: rgba(30, 30, 45, 0.95);
    color: #d4b8e0;
    border: 1.5px solid rgba(212, 184, 224, 0.3);
    padding: 14px 24px;
    border-radius: 50px;
    z-index: 600;
    opacity: 0;
    transition: opacity 0.3s, transform 0.3s;
    pointer-events: none;
    font-weight: 700;
    font-size: 12px;
    max-width: 90%;
    text-align: center;
}

.toast.show { opacity: 1; transform: translate(-50%, 0); }

.confetti { position: absolute; width: 10px; height: 15px; top: -20px; z-index: 599; animation: confettiFall linear forwards; pointer-events: none; font-size: 20px; }
@keyframes confettiFall { to { transform: translateY(900px) rotate(360deg); opacity: 0; } }

.quiz-activity-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin: 12px 0; }
.quiz-activity {
    padding: 16px 8px;
    border-radius: 16px;
    background: rgba(40, 40, 55, 0.7);
    border: 2px solid rgba(212, 184, 224, 0.1);
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    text-align: center;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    position: relative;
}

.quiz-activity.selected { border-color: #d4b8e0; background: rgba(212, 184, 224, 0.1); }
.quiz-activity.selected::after {
    content: "✓";
    position: absolute;
    top: 6px; right: 6px;
    width: 22px; height: 22px;
    display: flex; align-items: center; justify-content: center;
    background: #d4b8e0;
    color: #2a1a2a;
    border-radius: 50%;
    font-size: 12px;
    font-weight: bold;
}

.quiz-activity .act-emoji { font-size: 24px; }

.activity-subdetail { display: none; margin-top: 12px; padding: 14px; background: rgba(30, 30, 45, 0.7); border-radius: 16px; border: 1px solid rgba(212, 184, 224, 0.15); }
.activity-subdetail.active { display: block; }
.activity-subdetail-title { font-size: 11px; font-weight: 800; color: #d4b8e0; text-align: center; margin-bottom: 10px; }
.sub-option-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.sub-option { padding: 12px 8px; border-radius: 12px; background: rgba(40, 40, 55, 0.8); border: 1.5px solid rgba(212, 184, 224, 0.15); color: #fff; font-size: 10px; font-weight: 700; text-align: center; cursor: pointer; }
.sub-option.selected { border-color: #d4b8e0; background: rgba(212, 184, 224, 0.15); }

</style>
</head>

<body>

<!-- AURORA BACKGROUND (Simplified) -->
<div class="aurora"></div>

<!-- FLOATING PARTICLES -->
<div class="particles" id="particles"></div>

<!-- HELLO OVERLAY -->
<div class="hello-overlay" id="helloOverlay">
  <div class="hello-text">Hello 💛 Sweetie 💛</div>
</div>

<div class="iphone-stage">
<div class="iphone">

    <div class="dynamic-island" id="dynamicIsland">
        <div class="dynamic-island-content">
            <div class="di-icon">🎵</div>
            <div class="di-text">Now Playing</div>
            <div class="di-icon">▶️</div>
        </div>
    </div>

    <div class="screen">

        <div class="status-bar">
            <div class="status-left" id="statusTime">9:41</div>
            <div class="status-right">
                <span>📶</span>
                <span>📡</span>
                <div class="battery"><div class="battery-fill"></div></div>
            </div>
        </div>

        <div class="notif-banner" id="notifBanner" onclick="openQuizFromNotif()">
            <div class="notif-banner-icon" id="notifIcon">💬</div>
            <div class="notif-banner-content">
                <div class="notif-banner-title" id="notifTitle">Messages</div>
                <div class="notif-banner-body" id="notifBody">Your "NIKE" sent you a quiz for his "💛SWEETIE💛"</div>
            </div>
            <div class="notif-banner-time">now</div>
        </div>

        <!-- LOCK SCREEN -->
        <div class="lock-screen" id="lockScreen">
            <div class="lock-time" id="lockTime">9:41</div>
            <div class="lock-date" id="lockDate">Wednesday, September 16</div>
            <div class="lock-notifications" id="lockNotifications"></div>
            <div class="swipe-hint">Swipe up or tap to unlock 🔓</div>
            <div class="lock-bottom">
                <button class="lock-bottom-icon" onclick="toggleFlashlight(this)">🔦</button>
                <button class="lock-bottom-icon" onclick="toggleCamera(this)">📷</button>
            </div>
        </div>

        <!-- HOME SCREEN -->
        <div class="home-screen" id="homeScreen">
            <div class="app-grid">
                <div class="app-icon" onclick="openQuizApp()">
                    <div class="icon messages"><span>💬</span><div class="badge">1</div></div>
                    <span class="label">Messages</span>
                </div>
                <div class="app-icon" onclick="openQuizApp()">
                    <div class="icon quiz"><span>💛</span><div class="badge">!</div></div>
                    <span class="label">Quiz</span>
                </div>
                <div class="app-icon"><div class="icon photos">🌸</div><span class="label">Photos</span></div>
                <div class="app-icon"><div class="icon camera">📷</div><span class="label">Camera</span></div>
                <div class="app-icon"><div class="icon music">🎵</div><span class="label">Music</span></div>
                <div class="app-icon"><div class="icon weather">☀️</div><span class="label">Weather</span></div>
                <div class="app-icon"><div class="icon calendar">📅</div><span class="label">Calendar</span></div>
                <div class="app-icon"><div class="icon notes">📝</div><span class="label">Notes</span></div>
                <div class="app-icon"><div class="icon mail">✉️</div><span class="label">Mail</span></div>
                <div class="app-icon"><div class="icon maps">🗺️</div><span class="label">Maps</span></div>
                <div class="app-icon"><div class="icon health">❤️</div><span class="label">Health</span></div>
                <div class="app-icon" onclick="openControlCenter()">
                    <div class="icon settings">⚙️</div><span class="label">Settings</span>
                </div>
                <div class="app-icon"><div class="icon whatsapp">💚</div><span class="label">WhatsApp</span></div>
                <div class="app-icon"><div class="icon instagram">📷</div><span class="label">Instagram</span></div>
                <div class="app-icon"><div class="icon snapchat">👻</div><span class="label">Snapchat</span></div>
                <div class="app-icon" onclick="openControlCenter()">
                    <div class="icon settings">⚙️</div><span class="label">Settings</span>
                </div>
            </div>

            <div class="page-dots">
                <div class="dot active"></div>
                <div class="dot"></div>
            </div>

            <div class="dock">
                <div class="app-icon" onclick="openQuizApp()"><div class="icon messages"><span>💬</span></div></div>
                <div class="app-icon"><div class="icon camera">📷</div></div>
                <div class="app-icon"><div class="icon photos">🌸</div></div>
                <div class="app-icon" onclick="openControlCenter()"><div class="icon settings">⚙️</div></div>
            </div>
        </div>

        <!-- CONTROL CENTER -->
        <div class="control-center" id="controlCenter">
            <div class="cc-header">
                <h3>Control Center</h3>
                <button class="cc-close" onclick="closeControlCenter()">✕</button>
            </div>

            <div class="cc-grid">
                <div class="cc-tile">
                    <div class="cc-tile-title">Connectivity</div>
                    <div class="cc-tile-row">
                        <button class="cc-toggle-btn on" onclick="toggleCC(this)">📶</button>
                        <button class="cc-toggle-btn on" onclick="toggleCC(this)">📡</button>
                        <button class="cc-toggle-btn" onclick="toggleCC(this)">✈️</button>
                    </div>
                </div>
                <div class="cc-tile">
                    <div class="cc-tile-title">Focus</div>
                    <div class="cc-tile-row">
                        <button class="cc-toggle-btn" onclick="toggleCC(this)">🌙</button>
                        <button class="cc-toggle-btn on" onclick="toggleCC(this)">🔔</button>
                    </div>
                </div>
                <div class="cc-tile wide">
                    <div class="cc-tile-title">Brightness</div>
                    <div class="cc-slider-row">
                        <span class="slider-icon">🔅</span>
                        <input type="range" min="20" max="100" value="80" oninput="setBrightness(this.value)">
                        <span class="slider-icon">🔆</span>
                    </div>
                </div>
                <div class="cc-tile wide">
                    <div class="cc-tile-title">Volume</div>
                    <div class="cc-slider-row">
                        <span class="slider-icon">🔈</span>
                        <input type="range" min="0" max="100" value="60" oninput="setVolume(this.value)">
                        <span class="slider-icon">🔊</span>
                    </div>
                </div>
                <div class="cc-tile wide">
                    <div class="cc-tile-title">Now Playing</div>
                    <div class="cc-music">
                        <div class="cc-music-art">💛</div>
                        <div class="cc-music-info">
                            <div class="cc-music-title">Our Little Song</div>
                            <div class="cc-music-artist">Made for you</div>
                        </div>
                        <div class="cc-music-controls">
                            <button>⏮️</button><button>⏯️</button><button>⏭️</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="cc-permissions">
                <h4>🛡️ App Permissions</h4>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">📷</div><div class="permission-text">Camera</div></div>
                    <button class="ios-toggle" onclick="togglePermission(this, 'Camera')"></button>
                </div>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">📍</div><div class="permission-text">Location</div></div>
                    <button class="ios-toggle" onclick="togglePermission(this, 'Location')"></button>
                </div>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">👥</div><div class="permission-text">Contacts</div></div>
                    <button class="ios-toggle" onclick="togglePermission(this, 'Contacts')"></button>
                </div>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">🔔</div><div class="permission-text">Notifications</div></div>
                    <button class="ios-toggle on" onclick="togglePermission(this, 'Notifications')"></button>
                </div>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">🎤</div><div class="permission-text">Microphone</div></div>
                    <button class="ios-toggle" onclick="togglePermission(this, 'Microphone')"></button>
                </div>
                <div class="permission-row">
                    <div class="permission-info"><div class="permission-icon">🖼️</div><div class="permission-text">Photos</div></div>
                    <button class="ios-toggle on" onclick="togglePermission(this, 'Photos')"></button>
                </div>
            </div>
        </div>

        <!-- QUIZ APP -->
        <div class="app-view" id="quizApp">
            <div class="app-top-bar">
                <button class="app-back-btn" onclick="closeQuizApp()">‹ Messages</button>
                <div class="app-title">
                    <div class="app-title-avatar">💛</div>
                    Our Little Quiz
                </div>
                <button class="app-more-btn">⋯</button>
            </div>

            <div class="app-content" id="appContent">

                <div class="quiz-header">
                    <div class="small-title">A tiny game made with love</div>
                    <h1>Our Little Quiz 💛</h1>
                </div>

                <div class="quiz-progress">
                    <div class="quiz-progress-top">
                        <span id="qProgressText">Ready? 💛</span>
                        <span id="qStepText">1 / 10</span>
                    </div>
                    <div class="quiz-progress-bar">
                        <div class="quiz-progress-fill" id="qProgressBar"></div>
                    </div>
                </div>

                <!-- SCREEN 1 -->
                <section class="quiz-screen active" data-step="1">
                    <div class="quiz-hero">
                        <div class="hero-emoji">💛</div>
                        <h2>Do You Want to Play This Game?</h2>
                        <p>A tiny quiz made especially for you. Some questions, some food, and one little surprise ✨</p>
                        <h3 style="margin-top:16px;color:#d4b8e0;font-size:11px;letter-spacing:2px;">TRY TO CLICK "NO" 😏</h3>
                        <div class="quiz-buttons">
                            <button class="quiz-btn primary" onclick="qNext()">Yes 💛</button>
                            <button class="quiz-btn secondary no-btn" id="noBtn">No 😏</button>
                        </div>
                    </div>
                </section>

                <!-- SCREEN 2 -->
                <section class="quiz-screen" data-step="2">
                    <h2 class="quiz-question-title">🍽️ Let's Talk About Food</h2>
                    <p class="quiz-question-sub">Choose one food category first.</p>
                    <div class="quiz-option-grid">
                        <div class="quiz-option" id="catStreet" onclick="qSelectFood('street', this)">
                            <img src="Street Food .jpg" alt="Street Food" onerror="imgFallback(this,'STREET FOOD','2a2a3a','d4b8e0')">
                            <div class="quiz-option-label">🌮 Street Food</div>
                        </div>
                        <div class="quiz-option" id="catHomemade" onclick="qSelectFood('homemade', this)">
                            <img src="Home Made.jpg" alt="Homemade" onerror="imgFallback(this,'HOMEMADE FOOD','2a2a3a','d4b8e0')">
                            <div class="quiz-option-label">🥘 Homemade</div>
                        </div>
                    </div>
                    <div class="quiz-option-grid single" style="margin-top:10px;">
                        <div class="quiz-option" id="catCustom" onclick="qSelectFood('custom', this)">
                            <img src="ChatGPT Image Aug 20, 2026, 08_06_55 PM.png" alt="Custom" onerror="imgFallback(this,'WHAT I MAKE','3a1a2a','d4b8e0')">
                            <div class="quiz-option-label">👨‍🍳 What I Make</div>
                        </div>
                    </div>

                    <div class="quiz-subdetail" id="streetSubDetail">
                        <div class="quiz-subdetail-title">🌮 Choose Your Street Food</div>
                        <div class="quiz-subdetail-sub">Pick your favorite one</div>
                        <div class="quiz-dish-grid">
                            <div class="quiz-dish" onclick="qSelectDish('street','Pani Puri',this)">
                                <img src="Pani Puri.jpg" alt="Pani Puri" onerror="imgFallback(this,'Pani Puri','2a2a1a','d4b8e0')">
                                <div class="quiz-dish-label">Pani Puri 🥙</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('street','Vada Pav',this)">
                                <img src="vada [av.jpg" alt="Vada Pav" onerror="imgFallback(this,'Vada Pav','2a2a1a','d4b8e0')">
                                <div class="quiz-dish-label">Vada Pav 🍔</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('street','Dabeli',this)">
                                <img src="Dabeli.jpg" alt="Dabeli" onerror="imgFallback(this,'Dabeli','2a1a2a','d4b8e0')">
                                <div class="quiz-dish-label">Dabeli 🌮</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('street','Pav Bhaji',this)">
                                <img src="Pav Bhagi.jpg" alt="Pav Bhaji" onerror="imgFallback(this,'Pav Bhaji','1a1a3a','d4b8e0')">
                                <div class="quiz-dish-label">Pav Bhaji 🥪</div>
                            </div>
                        </div>
                    </div>

                    <div class="quiz-subdetail" id="homemadeSubDetail">
                        <div class="quiz-subdetail-title">🥘 Choose Your Vegetable Dish</div>
                        <div class="quiz-dish-grid">
                            <div class="quiz-dish" onclick="qSelectDish('homemade','Bhindi Masala',this)">
                                <img src="Bhindi Masala.jpg" alt="Bhindi" onerror="imgFallback(this,'Bhindi Masala','1a3a1a','d4b8e0')">
                                <div class="quiz-dish-label">Bhindi Masala</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('homemade','Paneer',this)">
                                <img src="Paneer.jpg" alt="Paneer" onerror="imgFallback(this,'Paneer','3a2a1a','d4b8e0')">
                                <div class="quiz-dish-label">Paneer 🧀</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('homemade','Dal Tadka',this)">
                                <img src="Dal tadka.jpg" alt="Dal" onerror="imgFallback(this,'Dal Tadka','3a2a1a','d4b8e0')">
                                <div class="quiz-dish-label">Dal Tadka 🍲</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectDish('homemade','Rajma-Chawal',this)">
                                <img src="Rajma-Chawal.webp" alt="Rajma" onerror="imgFallback(this,'Rajma Chawal','2a1a2a','d4b8e0')">
                                <div class="quiz-dish-label">Rajma-Chawal 🥗</div>
                            </div>
                        </div>
                        <div class="quiz-subdetail-title" style="margin-top:16px;">🫓 Choose Your Roti</div>
                        <div class="quiz-dish-grid single">
                            <div class="quiz-dish" onclick="qSelectRoti('Normal Roti',this)">
                                <img src="Normal Roti.jpg" alt="Roti" onerror="imgFallback(this,'Normal Roti','2a2a2a','d4b8e0')">
                                <div class="quiz-dish-label">🫓 Normal Roti</div>
                            </div>
                            <div class="quiz-dish" onclick="qSelectRoti('Butter Roti',this)">
                                <img src="Buttor Roti.jpg" alt="Butter Roti" onerror="imgFallback(this,'Butter Roti','3a2a1a','d4b8e0')">
                                <div class="quiz-dish-label">🧈🫓 Butter Roti</div>
                            </div>
                        </div>
                    </div>

                    <div class="quiz-subdetail" id="customSubDetail">
                        <div class="quiz-subdetail-title">👨‍🍳 What Should I Make?</div>
                        <div class="quiz-subdetail-sub">You can write anything you'd like</div>
                        <div class="quiz-field" style="margin-top:6px;">
                            <textarea id="customFood" placeholder="Tell me what food you want me to make... 💛"></textarea>
                        </div>
                    </div>

                    <div class="quiz-buttons">
                        <button class="quiz-btn primary" onclick="qNextFood()">Continue 🍦</button>
                    </div>
                </section>

                <!-- SCREEN 3 -->
                <section class="quiz-screen" data-step="3">
                    <h2 class="quiz-question-title">🍦 Ice Cream Time!</h2>
                    <p class="quiz-question-sub">Choose a company first.</p>
                    <div class="quiz-option-grid">
                        <div class="quiz-option" onclick="qSelectCompany('Vadilal',this)">
                            <img src="Vadilal Logo.png" alt="Vadilal" onerror="imgFallback(this,'Vadilal','2a2a2a','d4b8e0')">
                            <div class="quiz-option-label">Vadilal</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectCompany('Amul',this)">
                            <img src="Amul Logo.JPEG.avif" alt="Amul" onerror="imgFallback(this,'Amul','2a2a2a','d4b8e0')">
                            <div class="quiz-option-label">Amul</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectCompany('Kwality Walls',this)">
                            <img src="Kwality Walls.jpg" alt="Kwality" onerror="imgFallback(this,'Kwality Walls','1a2a3a','d4b8e0')">
                            <div class="quiz-option-label">Kwality Walls</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectCompany('Hokey Pokey',this)">
                            <img src="Hokey Pokey.jpg" alt="Hokey" onerror="imgFallback(this,'Hokey Pokey','2a1a3a','d4b8e0')">
                            <div class="quiz-option-label">Hokey Pokey</div>
                        </div>
                    </div>
                    <h3 style="text-align:center;color:#fff;font-size:14px;margin:18px 0 10px;" id="qFlavorTitle">🍨 Choose Your Flavor</h3>
                    <div class="quiz-option-grid">
                        <div class="quiz-option" onclick="qSelectFlavor('Chocolate',this)">
                            <img src="Chocolate.jpg" alt="Chocolate" onerror="imgFallback(this,'Chocolate','2a1a1a','d4b8e0')">
                            <div class="quiz-option-label">🍫 Chocolate</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectFlavor('Vanilla',this)">
                            <img src="vanilla.jpg" alt="Vanilla" onerror="imgFallback(this,'Vanilla','2a2a2a','d4b8e0')">
                            <div class="quiz-option-label">🍦 Vanilla</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectFlavor('Strawberry',this)">
                            <img src="Strawberry.jpg" alt="Strawberry" onerror="imgFallback(this,'Strawberry','2a1a2a','d4b8e0')">
                            <div class="quiz-option-label">🍓 Strawberry</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectFlavor('Butterscotch',this)">
                            <img src="Butterscotch.jpg" alt="Butterscotch" onerror="imgFallback(this,'Butterscotch','3a2a1a','d4b8e0')">
                            <div class="quiz-option-label">🍯 Butterscotch</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectFlavor('Mango',this)">
                            <img src="Mango.jpg" alt="Mango" onerror="imgFallback(this,'Mango','3a2a0a','d4b8e0')">
                            <div class="quiz-option-label">🥭 Mango</div>
                        </div>
                        <div class="quiz-option" onclick="qSelectFlavor('Cookies & Cream',this)">
                            <img src="Cookies & Cream.jpg" alt="Cookies" onerror="imgFallback(this,'Cookies','2a2a2a','d4b8e0')">
                            <div class="quiz-option-label">🍪 Cookies</div>
                        </div>
                    </div>
                    <div class="quiz-buttons">
                        <button class="quiz-btn primary" onclick="qNextIceCream()">Continue 💛</button>
                    </div>
                </section>

                <!-- SCREEN 4 -->
                <section class="quiz-screen" data-step="4">
                    <div class="quiz-hero">
                        <div class="hero-emoji">💬</div>
                        <h2>Do you feel happy and comfortable talking with me?</h2>
                        <p>Be honest... there is no wrong answer 😌</p>
                        <div class="quiz-buttons">
                            <button class="quiz-btn primary" onclick="qComfortableYes()">Yes 💛</button>
                            <button class="quiz-btn secondary" onclick="qComfortableMeet()">Tell you when we meet 😊</button>
                        </div>
                    </div>
                </section>

                <!-- SCREEN 5 — CHESS -->
                <section class="quiz-screen" data-step="5">
                    <div class="chess-section">
                        <div class="chess-badge">♔ ROYAL CHESS CHALLENGE ♚</div>
                        <h2 class="quiz-question-title">♟️ Chess Game</h2>
                        <p class="quiz-question-sub">Defeat the computer in chess to unlock the meeting 💛</p>
                        <div class="chess-progress-row">
                            <span>♙ Captured</span>
                            <strong><span id="chessCapturedCount">0</span> / 3</strong>
                        </div>
                        <div class="chess-message" id="chessMessage">Capture 3 pieces to unlock 💛</div>
                        <div class="chess-captured" id="chessCapturedPieces"></div>
                        <div class="chess-status">
                            <div class="chess-status-icon" id="chessTurnIcon">♔</div>
                            <div class="chess-status-text">
                                <strong id="chessStatus">Your turn — White!</strong>
                                <span>You ♔ | Computer ♚</span>
                            </div>
                        </div>
                        <div class="chess-board-wrapper">
                            <div class="chess-board" id="chessBoard"></div>
                        </div>
                        <div class="chess-result" id="chessResult">
                            <div class="chess-result-icon" id="chessResultIcon">✨</div>
                            <h3 id="chessResultTitle">Win to continue 💛</h3>
                            <p id="chessResultMessage">Capture 3 pieces to unlock the meeting.</p>
                        </div>
                        <div class="meeting-unlocked" id="meetingUnlocked">
                            <div class="big-emoji">💛</div>
                            <h3>🏆 CHECKMATE! YOU WIN! 🏆</h3>
                            <p><span class="highlight-text">💛SWEETIE💛</span>, you defeated the computer!<br>You've unlocked the <strong>meeting with NICK</strong>! 💛</p>
                            <div class="big-emoji">🎉 💛 ✨</div>
                            <p class="sub-text">Let's plan our meeting 📅</p>
                            <div style="font-size:28px;margin-top:8px;">♔ ♕ ♖ ♗ ♘ ♙</div>
                        </div>
                        <div class="quiz-buttons" style="margin-top:16px;">
                            <button class="quiz-btn secondary" onclick="resetChessGame()">🔄 New Game</button>
                        </div>
                    </div>
                </section>

                <!-- SCREEN 6 -->
                <section class="quiz-screen" data-step="6">
                    <h2 class="quiz-question-title">📅 Meeting Plan</h2>
                    <div class="quiz-field">
                        <label>📅 Date</label>
                        <input type="date" id="qMeetingDate">
                    </div>
                    <div class="quiz-field">
                        <label>⏰ Time</label>
                        <select id="qMeetingTime"><option value="">Select Time</option></select>
                    </div>
                    <h3 style="text-align:center;color:#fff;font-size:14px;margin:16px 0 8px;">✨ What Can We Do? (Choose min 3)</h3>
                    <div class="quiz-activity-grid">
                        <div class="quiz-activity" onclick="qToggleActivity('movie',this)"><span class="act-emoji">🎬</span>Watch Movie</div>
                        <div class="quiz-activity" onclick="qToggleActivity('garden',this)"><span class="act-emoji">🌳</span>Garden</div>
                        <div class="quiz-activity" onclick="qToggleActivity('mall',this)"><span class="act-emoji">🛍️</span>Mall</div>
                        <div class="quiz-activity" onclick="qToggleActivity('sport',this)"><span class="act-emoji">🏸</span>Sport</div>
                    </div>
                    <div class="activity-subdetail" id="subMovie">
                        <div class="activity-subdetail-title">🎬 Choose Movie Genre</div>
                        <div class="sub-option-grid">
                            <div class="sub-option" onclick="qSelectSubOption('movie','Action',this)">Action</div>
                            <div class="sub-option" onclick="qSelectSubOption('movie','Comedy',this)">Comedy</div>
                            <div class="sub-option" onclick="qSelectSubOption('movie','Romance',this)">Romance</div>
                            <div class="sub-option" onclick="qSelectSubOption('movie','Thriller',this)">Thriller</div>
                        </div>
                    </div>
                    <div class="activity-subdetail" id="subGarden">
                        <div class="activity-subdetail-title">🌳 Choose Garden Spot</div>
                        <div class="sub-option-grid">
                            <div class="sub-option" onclick="qSelectSubOption('garden','Rose Garden',this)">Rose Garden</div>
                            <div class="sub-option" onclick="qSelectSubOption('garden','Lake View',this)">Lake View</div>
                            <div class="sub-option" onclick="qSelectSubOption('garden','Botanical Park',this)">Botanical Park</div>
                            <div class="sub-option" onclick="qSelectSubOption('garden','Sunset Point',this)">Sunset Point</div>
                        </div>
                    </div>
                    <div class="activity-subdetail" id="subMall">
                        <div class="activity-subdetail-title">🛍️ Choose Mall Activity</div>
                        <div class="sub-option-grid">
                            <div class="sub-option" onclick="qSelectSubOption('mall','Gaming Zone',this)">🎮 Gaming Zone</div>
                            <div class="sub-option" onclick="qSelectSubOption('mall','Nice Shopping Mall',this)">🛒 Shopping Mall</div>
                            <div class="sub-option" onclick="qSelectSubOption('mall','Food Court',this)">🍔 Food Court</div>
                            <div class="sub-option" onclick="qSelectSubOption('mall','Explore Mall',this)">🗺️ Explore Mall</div>
                        </div>
                    </div>
                    <div class="activity-subdetail" id="subSport">
                        <div class="activity-subdetail-title">🏸 Choose Sport</div>
                        <div class="sub-option-grid">
                            <div class="sub-option" onclick="qSelectSubOption('sport','Chess',this)">♟️ Chess</div>
                            <div class="sub-option" onclick="qSelectSubOption('sport','Badminton',this)">🏸 Badminton</div>
                            <div class="sub-option" onclick="qSelectSubOption('sport','Riding',this)">🚴 Riding</div>
                            <div class="sub-option" onclick="qSelectSubOption('sport','Yourself',this)">✨ Yourself</div>
                        </div>
                    </div>
                    <div class="quiz-buttons">
                        <button class="quiz-btn primary" onclick="qFinishMeeting()">Fix Meeting 💛</button>
                    </div>
                </section>

                <!-- SCREEN 7 -->
                <section class="quiz-screen" data-step="7">
                    <div class="friendship-card">
                        <div class="friendship-heart">💛</div>
                        <h2 style="color:#fff;font-size:18px;margin-top:10px;">Friendship Level</h2>
                        <div class="friendship-level" id="qFriendshipLevel">0%</div>
                        <div class="friendship-bar"><div class="friendship-fill" id="qFriendshipFill"></div></div>
                        <p style="color:rgba(255,255,255,0.5);font-size:12px;margin-top:10px;">
                            <strong style="color:#d4b8e0;">100% 💛</strong><br>*No upgrade required* 😌
                        </p>
                        <div class="meeting-card" id="qMeetingSummary" style="display:none;">
                            <h3>📅 Our Meeting Plan</h3>
                            <p><strong>Date:</strong> <span id="qSummaryDate">—</span></p>
                            <p><strong>Time:</strong> <span id="qSummaryTime">—</span></p>
                            <p><strong>Activity:</strong> <span id="qSummaryActivity">—</span></p>
                        </div>
                    </div>
                </section>

                <!-- SCREEN 8 -->
                <section class="quiz-screen" data-step="8">
                    <div class="surprise-box">
                        <div class="win-banner"> 💛SWEETIE💛 🏆 YOU WIN! 🏆</div>
                        <div class="surprise-icon" onclick="qRevealSurprise(this)">🎁</div>
                        <h2 style="color:#fff;font-size:18px;margin-top:10px;">Tap to Reveal Surprise! 💛</h2>
                        <div class="surprise-content" id="qSurpriseContent">
                            <h3 style="font-size:20px;color:#d4b8e0;font-weight:900;">🏆 YOU WIN! 🏆</h3>
                            <p style="margin-top:10px;font-size:15px;font-weight:800;color:#fff;">You completed the whole quiz! 🎉</p>
                            <p style="margin-top:12px;font-size:15px;color:#d4b8e0;font-weight:800;">You're my favorite person! 💛</p>
                            <div style="font-size:24px;margin-top:12px;">🎉 💛 ✨ 🎉</div>
                        </div>
                        <div class="quiz-buttons">
                            <button class="quiz-btn primary" onclick="qNext()">Continue 💛</button>
                        </div>
                    </div>
                </section>

                <!-- SCREEN 9 -->
                <section class="quiz-screen" data-step="9">
                    <div class="quiz-hero">
                        <div class="hero-emoji">💛</div>
                        <h2>Why I Talk With You?</h2>
                        <p>There's a special reason...</p>
                    </div>
                    <div style="text-align:center;padding:15px;background:rgba(212,184,224,0.06);border:2px solid rgba(212,184,224,0.2);border-radius:20px;margin:16px 0;">
                        <div style="font-size:36px;margin-bottom:10px;">🤔</div>
                        <h3 style="color:#fff;font-size:14px;margin-bottom:16px;">Why I talk with you and why you special for me? 💛</h3>
                        <button class="quiz-btn primary" onclick="qRevealReason(this)" style="font-size:11px;padding:12px 20px;">✨ Click to Reveal Reason ✨</button>
                        <div id="qSpecialReason" style="display:none;margin-top:16px;padding:16px;background:rgba(30,30,45,0.8);border-radius:16px;border:2px solid rgba(212,184,224,0.2);">
                            <div style="font-size:30px;margin-bottom:8px;">😊</div>
                            <p style="font-size:14px;font-weight:800;color:#d4b8e0;">I will tell you when we meet 💛</p>
                            <div style="font-size:20px;margin-top:8px;">✨ 💛 ✨</div>
                        </div>
                    </div>
                    <div class="quiz-buttons">
                        <button class="quiz-btn primary" onclick="qNext()">Continue 💛</button>
                    </div>
                </section>

                <!-- SCREEN 10 -->
                <section class="quiz-screen" data-step="10">
                    <div class="quiz-hero">
                        <div class="hero-emoji">💛</div>
                        <h2>Thank You! 🥹</h2>
                        <p>This quiz was made with love, just for you 💛✨</p>
                    </div>
                    <div style="text-align:center;padding:20px;background:rgba(212,184,224,0.05);border:2px solid rgba(212,184,224,0.2);border-radius:20px;margin:16px 0;">
                        <div style="font-size:38px;margin-bottom:8px;">📱</div>
                        <h3 style="color:#fff;font-size:15px;margin-bottom:6px;">Want to Talk to Your NIKE? 💛</h3>
                        <p style="color:rgba(255,255,255,0.5);font-size:12px;margin-bottom:12px;">Just one tap away 😊</p>
                        <div class="phone-display">📞 +91 9265078473</div>
                        <div class="contact-buttons">
                            <a class="contact-btn call" href="tel:+919265078473">📞 Call Me</a>
                            <a class="contact-btn msg" href="sms:+919265078473?body=Hey!">💬 Message Me</a>
                            <a class="contact-btn wa" href="https://wa.me/919265078473" target="_blank">💚 WhatsApp</a>
                        </div>
                    </div>
                    <div class="quiz-buttons">
                        <button class="quiz-btn primary" onclick="qRestart()">Play Again 🔄</button>
                    </div>
                </section>

            </div>
        </div>

        <div class="home-bar" onclick="goHome()"></div>
        <div class="toast" id="qToast"></div>

    </div>
</div>
</div>

<script>

/* =====================================================
   FLOATING PARTICLES (Reduced for performance)
===================================================== */
(function createParticles() {
    const container = document.getElementById('particles');
    if (!container) return;
    for (let i = 0; i < 15; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (10 + Math.random() * 10) + 's';
        p.style.animationDelay = (Math.random() * 10) + 's';
        const colors = ['#d4b8e0', '#c9a9b8', '#e8c8d0', '#f0d0e0'];
        p.style.background = colors[Math.floor(Math.random() * colors.length)];
        container.appendChild(p);
    }
})();

/* =====================================================
   CLOCK
===================================================== */
function updateClock() {
    const now = new Date();
    const h = now.getHours();
    const m = String(now.getMinutes()).padStart(2, '0');
    const h12 = h === 0 ? 12 : (h > 12 ? h - 12 : h);
    const timeStr = `${h12}:${m}`;
    const statusTime = document.getElementById('statusTime');
    const lockTime = document.getElementById('lockTime');
    if (statusTime) statusTime.textContent = timeStr;
    if (lockTime) lockTime.textContent = timeStr;
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    const dateStr = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}`;
    const lockDate = document.getElementById('lockDate');
    if (lockDate) lockDate.textContent = dateStr;
}
updateClock();
setInterval(updateClock, 30000);

/* =====================================================
   HELLO OVERLAY
===================================================== */
setTimeout(() => {
  const hello = document.getElementById('helloOverlay');
  if (hello) {
    hello.classList.add('hide');
    setTimeout(() => { hello.style.display = 'none'; }, 1500);
  }
}, 3500);

/* =====================================================
   NOTIFICATIONS
===================================================== */
const NOTIFICATION_ROTATION = [
    { icon: '💬', type: 'messages', title: 'Messages',  body: 'Your NIKE sent you a quiz 💛',        time: 'now' },
    { icon: '🎵', type: 'music',    title: 'Music',     body: 'Now playing: Our Little Song 🎧',     time: 'now' },
    { icon: '💚', type: 'whatsapp', title: 'WhatsApp',  body: 'Your NIKE: Let\'s chat soon 💛',      time: 'now' },
    { icon: '📷', type: 'instagram',title: 'Instagram', body: 'Your NIKE liked your photo ❤️',       time: 'now' },
    { icon: '👻', type: 'snapchat', title: 'Snapchat',  body: 'Your NIKE sent a Snap! 👀',           time: 'now' },
    { icon: '❤️', type: 'health',   title: 'Health',    body: 'Your heart rate increased 💓',        time: 'now' }
];

const lockNotifications = document.getElementById('lockNotifications');
let notifRotationIndex = 0;

function addLockNotification(n, prepend = true) {
    const el = document.createElement('div');
    el.className = 'lock-notif';
    el.innerHTML = `
        <div class="lock-notif-icon ${n.type}">${n.icon}</div>
        <div class="lock-notif-content">
            <div class="lock-notif-title">${n.title}</div>
            <div class="lock-notif-body">${n.body}</div>
            <div class="lock-notif-time">${n.time}</div>
        </div>
    `;
    el.onclick = () => {
        if (n.type === 'messages') unlockAndOpenQuiz();
        else unlockPhone();
    };
    if (prepend && lockNotifications.firstChild) {
        lockNotifications.insertBefore(el, lockNotifications.firstChild);
    } else {
        lockNotifications.appendChild(el);
    }
    while (lockNotifications.children.length > 3) {
        lockNotifications.removeChild(lockNotifications.lastChild);
    }
}

addLockNotification(NOTIFICATION_ROTATION[0], false);
addLockNotification(NOTIFICATION_ROTATION[5], false);
addLockNotification(NOTIFICATION_ROTATION[1], false);

setInterval(() => {
    notifRotationIndex = (notifRotationIndex + 1) % NOTIFICATION_ROTATION.length;
    const notif = NOTIFICATION_ROTATION[notifRotationIndex];
    addLockNotification({ ...notif, time: 'now' }, true);
    if (homeScreen.classList.contains('active') || quizApp.classList.contains('active')) {
        showNotifBanner(notif.icon, notif.title, notif.body);
    }
}, 30000);

setTimeout(() => {
    showNotifBanner('💬', 'Messages', 'Your "NIKE" sent you a quiz for his "💛SWEETIE💛"');
}, 2500);

/* =====================================================
   LOCK / HOME
===================================================== */
const lockScreen = document.getElementById('lockScreen');
const homeScreen = document.getElementById('homeScreen');

let touchStartY = 0;
lockScreen.addEventListener('touchstart', (e) => { touchStartY = e.touches[0].clientY; });
lockScreen.addEventListener('touchend', (e) => {
    const endY = e.changedTouches[0].clientY;
    if (touchStartY - endY > 40) unlockPhone();
});
lockScreen.addEventListener('click', (e) => {
    if (e.target.classList.contains('lock-bottom-icon')) return;
    unlockPhone();
});

function unlockPhone() {
    lockScreen.classList.add('hidden');
    homeScreen.classList.add('active');
    vibrate(20);
}
function lockPhone() {
    homeScreen.classList.remove('active');
    lockScreen.classList.remove('hidden');
}
function toggleFlashlight(btn) {
    btn.style.background = btn.style.background === 'rgba(255,255,255,0.3)' ? '' : 'rgba(255,255,255,0.3)';
    btn.textContent = btn.textContent === '🔦' ? '💡' : '🔦';
}
function toggleCamera(btn) { qToast('📷 Camera opened'); }

/* =====================================================
   CONTROL CENTER
===================================================== */
const controlCenter = document.getElementById('controlCenter');
function openControlCenter() { controlCenter.classList.add('active'); vibrate(10); }
function closeControlCenter() { controlCenter.classList.remove('active'); }
function toggleCC(btn) { btn.classList.toggle('on'); vibrate(10); }
function togglePermission(btn, name) {
    btn.classList.toggle('on');
    const enabled = btn.classList.contains('on');
    qToast(`${enabled ? '✅' : '❌'} ${name} ${enabled ? 'enabled' : 'disabled'}`);
    vibrate(10);
}
function setBrightness(val) { document.querySelector('.screen').style.filter = `brightness(${val/100})`; }
function setVolume(val) {}

/* =====================================================
   APP VIEW
===================================================== */
const quizApp = document.getElementById('quizApp');
function openQuizApp() {
    homeScreen.classList.remove('active');
    quizApp.classList.add('active');
    vibrate(15);
    setTimeout(() => showNotifBanner('💛', 'Our Little Quiz', 'Your NIKE says: Let\'s begin! "💛SWEETIE💛"'), 700);
}
function closeQuizApp() {
    quizApp.classList.remove('active');
    homeScreen.classList.add('active');
    vibrate(10);
}
function openQuizFromNotif() { hideNotifBanner(); unlockPhone(); setTimeout(() => openQuizApp(), 300); }
function unlockAndOpenQuiz() { unlockPhone(); setTimeout(() => openQuizApp(), 400); }
function goHome() {
    if (controlCenter.classList.contains('active')) { closeControlCenter(); return; }
    if (quizApp.classList.contains('active')) { closeQuizApp(); return; }
    if (homeScreen.classList.contains('active')) { lockPhone(); return; }
}

/* =====================================================
   NOTIF BANNER
===================================================== */
const notifBanner = document.getElementById('notifBanner');
let notifTimer;
function showNotifBanner(icon, title, body) {
    document.getElementById('notifIcon').textContent = icon;
    document.getElementById('notifTitle').textContent = title;
    document.getElementById('notifBody').textContent = body;
    notifBanner.classList.add('show');
    clearTimeout(notifTimer);
    notifTimer = setTimeout(hideNotifBanner, 5000);
}
function hideNotifBanner() { notifBanner.classList.remove('show'); }
function vibrate(ms) { if (navigator.vibrate) navigator.vibrate(ms); }

/* =====================================================
   QUIZ LOGIC
===================================================== */
let qCurrentScreen = 1;
const qTotalScreens = 10;
let qSelectedFood = '';
let qSelectedDish = '';
let qSelectedRoti = '';
let qSelectedCompany = '';
let qSelectedFlavor = '';
let qComfortable = '';
let qActivities = [];
let qActivitySubOptions = { movie: '', garden: '', mall: '', sport: '' };

const qScreens = document.querySelectorAll('.quiz-screen');
const qProgressBar = document.getElementById('qProgressBar');
const qProgressText = document.getElementById('qProgressText');
const qStepText = document.getElementById('qStepText');

function qUpdateProgress() {
    const pct = ((qCurrentScreen - 1) / (qTotalScreens - 1)) * 100;
    qProgressBar.style.width = pct + '%';
    qStepText.textContent = qCurrentScreen + ' / ' + qTotalScreens;
    const labels = {
        1: 'Ready? 💛', 2: 'Food 🍽️', 3: 'Ice cream 🍦',
        4: 'A question 💬', 5: 'Chess ♟️',
        6: 'Meeting 📅', 7: 'Friendship 💛', 8: 'Surprise 🎁',
        9: 'Special 💛', 10: 'Contact 📱'
    };
    qProgressText.textContent = labels[qCurrentScreen] || 'Go';
}

function qShowScreen(n) {
    if (n < 1 || n > qTotalScreens) return;
    qScreens.forEach(s => s.classList.remove('active'));
    const target = document.querySelector(`.quiz-screen[data-step="${n}"]`);
    if (target) {
        target.classList.add('active');
        qCurrentScreen = n;
        qUpdateProgress();
        document.getElementById('appContent').scrollTo({ top: 0, behavior: 'smooth' });
        vibrate(8);
        if (n === 8) setTimeout(() => {
            const icon = document.querySelector('.surprise-icon');
            if (icon) qRevealSurprise(icon);
        }, 1000);
    }
}
function qNext() { qShowScreen(qCurrentScreen + 1); }

/* NO BUTTON */
const noBtn = document.getElementById('noBtn');
let noMoveCount = 0;
function moveNoFurther() {
    if (!noBtn) return;
    noMoveCount++;
    const parent = noBtn.parentElement;
    const maxX = Math.max(80, parent.clientWidth - noBtn.offsetWidth - 20);
    const maxY = Math.max(60, parent.clientHeight - noBtn.offsetHeight - 20);
    const baseX = Math.min(noMoveCount * 35, maxX);
    const baseY = Math.min(noMoveCount * 20, maxY);
    const randomX = (Math.random() * 80 - 40);
    const randomY = (Math.random() * 60 - 30);
    let tx = Math.max(-maxX/2, Math.min(maxX/2, baseX + randomX));
    let ty = Math.max(-maxY/2, Math.min(maxY/2, baseY + randomY));
    noBtn.style.transform = `translate(${tx}px, ${ty}px)`;
    qToast('Nike try 😏💛');
    vibrate(15);
}
if (noBtn) {
    noBtn.addEventListener('mouseenter', moveNoFurther);
    noBtn.addEventListener('click', (e) => { e.preventDefault(); moveNoFurther(); });
    noBtn.addEventListener('touchstart', (e) => { e.preventDefault(); moveNoFurther(); }, { passive: false });
}

/* FOOD */
function qSelectFood(cat, el) {
    qSelectedFood = cat;
    qSelectedDish = '';
    qSelectedRoti = '';
    document.querySelectorAll('.quiz-screen[data-step="2"] .quiz-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    ['streetSubDetail','homemadeSubDetail','customSubDetail'].forEach(id => {
        const e = document.getElementById(id);
        if (e) e.classList.remove('active');
    });
    document.querySelectorAll('.quiz-dish').forEach(d => d.classList.remove('selected'));
    if (cat === 'street')   document.getElementById('streetSubDetail').classList.add('active');
    if (cat === 'homemade') document.getElementById('homemadeSubDetail').classList.add('active');
    if (cat === 'custom')   document.getElementById('customSubDetail').classList.add('active');
    qSparkle(el);
    qToast('Great choice! 😋');
}
function qSelectDish(cat, name, el) {
    qSelectedDish = name;
    el.parentElement.querySelectorAll('.quiz-dish').forEach(d => d.classList.remove('selected'));
    el.classList.add('selected');
    qSparkle(el);
    qToast(name + ' selected 😋');
    vibrate(10);
}
function qSelectRoti(name, el) {
    qSelectedRoti = name;
    el.parentElement.querySelectorAll('.quiz-dish').forEach(d => d.classList.remove('selected'));
    el.classList.add('selected');
    qSparkle(el);
    qToast(name + ' selected 🫓');
    vibrate(10);
}
function qNextFood() {
    if (!qSelectedFood) { qToast('Choose a category first 💛'); return; }
    if (qSelectedFood === 'street' && !qSelectedDish) { qToast('Pick a street food 🌮'); return; }
    if (qSelectedFood === 'homemade' && !qSelectedDish) { qToast('Pick a vegetable dish 🥘'); return; }
    if (qSelectedFood === 'homemade' && !qSelectedRoti) { qToast('Pick normal or butter roti 🫓'); return; }
    if (qSelectedFood === 'custom') {
        const v = document.getElementById('customFood').value.trim();
        if (!v) { qToast('Write what you want me to make 👨‍🍳'); return; }
        qSelectedDish = v;
    }
    qNext();
}

/* ICE CREAM */
function qSelectCompany(c, el) {
    qSelectedCompany = c;
    document.querySelectorAll('.quiz-screen[data-step="3"] .quiz-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('qFlavorTitle').textContent = '🍨 Choose ' + c + ' Flavor';
    qSparkle(el);
    qToast(c + ' selected 🍦');
}
function qSelectFlavor(f, el) {
    qSelectedFlavor = f;
    document.querySelectorAll('.quiz-screen[data-step="3"] .quiz-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    qSparkle(el);
    qToast(f + ' sounds delicious! 🍦');
}
function qNextIceCream() {
    if (!qSelectedCompany) { qToast('Choose a company 🍦'); return; }
    if (!qSelectedFlavor) { qToast('Choose a flavor 🍨'); return; }
    qNext();
}
function qComfortableYes() {
    qComfortable = 'Yes';
    qShowScreen(5);
    qConfetti();
    qToast('Thank you! 💛');
}
function qComfortableMeet() {
    qComfortable = 'Will tell when we meet';
    resetChessGame();
    qShowScreen(5);
    qToast('Win the chess game first! ♟️💛');
}

/* MEETING */
function qToggleActivity(key, el) {
    el.classList.toggle('selected');
    const label = el.textContent.trim().replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim();
    if (el.classList.contains('selected')) {
        if (!qActivities.includes(label)) qActivities.push(label);
        const sub = document.getElementById('sub' + key.charAt(0).toUpperCase() + key.slice(1));
        if (sub) sub.classList.add('active');
    } else {
        qActivities = qActivities.filter(a => a !== label);
        qActivitySubOptions[key] = '';
        const sub = document.getElementById('sub' + key.charAt(0).toUpperCase() + key.slice(1));
        if (sub) {
            sub.classList.remove('active');
            sub.querySelectorAll('.sub-option').forEach(o => o.classList.remove('selected'));
        }
    }
    vibrate(10);
}
function qSelectSubOption(activity, value, el) {
    qActivitySubOptions[activity] = value;
    el.parentElement.querySelectorAll('.sub-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    vibrate(8);
    qToast(value + ' selected ✨');
}
function qFinishMeeting() {
    const date = document.getElementById('qMeetingDate').value;
    const time = document.getElementById('qMeetingTime').value;
    if (!date) { qToast('Pick a date 📅'); return; }
    if (!time) { qToast('Pick a time ⏰'); return; }
    if (qActivities.length < 3) { qToast('Choose at least 3 activities 😊'); return; }
    const d = new Date(date + 'T00:00:00');
    document.getElementById('qSummaryDate').textContent = isNaN(d.getTime()) ? date : d.toLocaleDateString(undefined, {day:'2-digit', month:'short', year:'numeric'});
    document.getElementById('qSummaryTime').textContent = time;
    let activityStr = qActivities.join(' • ');
    const subParts = [];
    if (qActivitySubOptions.movie) subParts.push('Movie: ' + qActivitySubOptions.movie);
    if (qActivitySubOptions.garden) subParts.push('Garden: ' + qActivitySubOptions.garden);
    if (qActivitySubOptions.mall) subParts.push('Mall: ' + qActivitySubOptions.mall);
    if (qActivitySubOptions.sport) subParts.push('Sport: ' + qActivitySubOptions.sport);
    if (subParts.length) activityStr += ' | ' + subParts.join(' | ');
    document.getElementById('qSummaryActivity').textContent = activityStr;
    document.getElementById('qMeetingSummary').style.display = 'block';
    qShowScreen(7);
    qConfetti();
    setTimeout(() => {
        document.getElementById('qFriendshipLevel').textContent = '100% 💛';
        document.getElementById('qFriendshipFill').style.width = '100%';
        qSaveQuiz();
        setTimeout(() => {
            qConfetti();
            qToast('🎉 Surprise unlocked! 🎁');
            qShowScreen(8);
        }, 2500);
    }, 400);
}
function qRevealSurprise(el) {
    const content = document.getElementById('qSurpriseContent');
    if (content && !content.classList.contains('show')) {
        content.classList.add('show');
        el.style.transform = 'scale(1.2)';
        el.textContent = '💝';
        qConfetti();
        qToast('Surprise revealed! 💛');
        vibrate([20, 50, 20]);
    }
}
function qRevealReason(btn) {
    const reason = document.getElementById('qSpecialReason');
    if (reason.style.display === 'none') {
        reason.style.display = 'block';
        btn.innerHTML = '💛 Hide Reason 💛';
        qConfetti();
        qToast('This is just between us 💛');
    } else {
        reason.style.display = 'none';
        btn.innerHTML = '✨ Click to Reveal Reason ✨';
    }
}
function qRestart() { location.reload(); }

/* =====================================================
   CHESS ENGINE (Performance Optimized)
===================================================== */
let chessBoard = [];
let chessSelected = null;
let chessTurn = 'w';
let chessGameOver = false;
let chessPlayerWins = false;
let chessCapturedByPlayer = [];
let chessLastMove = null;
let chessCheckState = false;
let chessTotalMoves = 0;

const PIECES = {
    'wK': '♔', 'wQ': '♕', 'wR': '♖', 'wB': '♗', 'wN': '♘', 'wP': '♙',
    'bK': '♚', 'bQ': '♛', 'bR': '♜', 'bB': '♝', 'bN': '♞', 'bP': '♟'
};

function initChessBoard() {
    chessBoard = [
        ['bR','bN','bB','bQ','bK','bB','bN','bR'],
        ['bP','bP','bP','bP','bP','bP','bP','bP'],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['wP','wP','wP','wP','wP','wP','wP','wP'],
        ['wR','wN','wB','wQ','wK','wB','wN','wR']
    ];
    chessSelected = null;
    chessTurn = 'w';
    chessGameOver = false;
    chessPlayerWins = false;
    chessCapturedByPlayer = [];
    chessLastMove = null;
    chessCheckState = false;
    chessTotalMoves = 0;
    renderChessBoard(true); // Full render
    updateChessUI();
}

function renderChessBoard(fullRender = false) {
    const boardEl = document.getElementById('chessBoard');
    if (!boardEl) return;

    if (fullRender) {
        boardEl.innerHTML = '';
        for (let r = 0; r < 8; r++) {
            for (let c = 0; c < 8; c++) {
                const square = document.createElement('div');
                square.className = `chess-square ${(r + c) % 2 === 0 ? 'light' : 'dark'}`;
                square.dataset.row = r;
                square.dataset.col = c;
                square.addEventListener('click', () => handleChessClick(r, c));
                boardEl.appendChild(square);
            }
        }
    }

    // Update pieces and highlights
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const square = boardEl.children[r * 8 + c];
            if (!square) continue;
            
            // Clear classes
            square.classList.remove('selected', 'valid-move', 'capture', 'last-move', 'check-flash');
            
            // Piece rendering
            const piece = chessBoard[r][c];
            let pieceEl = square.querySelector('.piece');
            if (piece) {
                if (!pieceEl) {
                    pieceEl = document.createElement('span');
                    pieceEl.className = 'piece';
                    square.appendChild(pieceEl);
                }
                if (pieceEl.textContent !== PIECES[piece]) {
                    pieceEl.textContent = PIECES[piece];
                    pieceEl.style.animation = 'none'; // Reset animation
                    void pieceEl.offsetWidth; // Trigger reflow
                    pieceEl.style.animation = 'piecePop 0.3s ease-out';
                }
            } else {
                if (pieceEl) pieceEl.remove();
            }

            // Highlights
            if (chessSelected && chessSelected.row === r && chessSelected.col === c) {
                square.classList.add('selected');
            }
            if (chessSelected && !chessGameOver && chessTurn === 'w') {
                const moves = getValidMoves(chessSelected.row, chessSelected.col, 'w');
                if (moves.some(m => m.row === r && m.col === c)) {
                    square.classList.add('valid-move');
                    if (chessBoard[r][c] && chessBoard[r][c][0] === 'b') square.classList.add('capture');
                }
            }
            if (chessLastMove) {
                if ((chessLastMove.from.row === r && chessLastMove.from.col === c) ||
                    (chessLastMove.to.row === r && chessLastMove.to.col === c)) {
                    square.classList.add('last-move');
                }
            }
        }
    }
}

function handleChessClick(r, c) {
    if (chessGameOver || chessTurn !== 'w' || chessPlayerWins) return;
    const piece = chessBoard[r][c];
    
    // If clicking own piece, select it
    if (piece && piece[0] === 'w') {
        chessSelected = { row: r, col: c };
        renderChessBoard();
        return;
    }
    
    // If a piece is selected and we click a valid move
    if (chessSelected) {
        const moves = getValidMoves(chessSelected.row, chessSelected.col, 'w');
        if (moves.some(m => m.row === r && m.col === c)) {
            makeChessMove(chessSelected.row, chessSelected.col, r, c);
        } else {
            chessSelected = null;
            renderChessBoard();
        }
    }
}

function makeChessMove(fromRow, fromCol, toRow, toCol) {
    const piece = chessBoard[fromRow][fromCol];
    const captured = chessBoard[toRow][toCol];
    
    // Highlight the moving piece temporarily
    const boardEl = document.getElementById('chessBoard');
    const fromSquare = boardEl.children[fromRow * 8 + fromCol];
    const pieceEl = fromSquare.querySelector('.piece');
    if (pieceEl) {
        pieceEl.classList.add('moving');
        setTimeout(() => pieceEl.classList.remove('moving'), 200);
    }

    chessLastMove = { from: { row: fromRow, col: fromCol }, to: { row: toRow, col: toCol } };
    
    if (captured && captured[0] === 'b') {
        chessCapturedByPlayer.push(captured);
        updateCapturedDisplay();
    }
    
    chessBoard[toRow][toCol] = piece;
    chessBoard[fromRow][fromCol] = '';
    
    if (piece === 'wP' && toRow === 0) chessBoard[toRow][toCol] = 'wQ';
    if (piece === 'bP' && toRow === 7) chessBoard[toRow][toCol] = 'bQ';
    
    chessSelected = null;
    chessTotalMoves++;
    
    const opponentKing = findKing(chessTurn === 'w' ? 'b' : 'w');
    chessCheckState = opponentKing ? isInCheck(chessTurn === 'w' ? 'b' : 'w') : false;
    
    if (chessCapturedByPlayer.length >= 3) {
        chessPlayerWins = true;
        chessGameOver = true;
        renderChessBoard();
        updateChessUI();
        showChessWin();
        return;
    }
    
    chessTurn = chessTurn === 'w' ? 'b' : 'w';
    renderChessBoard();
    updateChessUI();
    
    if (isCheckmate(chessTurn)) {
        if (chessTurn === 'b') { chessPlayerWins = true; chessGameOver = true; showChessWin(); }
        else { chessGameOver = true; showChessLose('Checkmate! Computer wins.'); }
        renderChessBoard();
        updateChessUI();
        return;
    }
    if (isStalemate(chessTurn)) {
        chessGameOver = true;
        showChessDraw();
        renderChessBoard();
        updateChessUI();
        return;
    }
    
    if (!chessGameOver && chessTurn === 'b') {
        updateChessStatus('Computer thinking...', '♚');
        setTimeout(computerChessMove, 400);
    }
}

function computerChessMove() {
    if (chessGameOver || chessTurn !== 'b') return;
    const moves = getAllValidMoves('b');
    if (moves.length === 0) {
        if (isInCheck('b')) { chessPlayerWins = true; chessGameOver = true; showChessWin(); }
        else { chessGameOver = true; showChessDraw(); }
        renderChessBoard();
        updateChessUI();
        return;
    }
    let bestMove = null, bestScore = -Infinity;
    for (const move of moves) {
        let score = 0;
        const captured = chessBoard[move.to.row][move.to.col];
        if (captured) {
            const values = { 'wP': 1, 'wN': 3, 'wB': 3, 'wR': 5, 'wQ': 9, 'wK': 100 };
            score += (values[captured] || 0) * 10;
        }
        const centerDist = Math.abs(move.to.row - 3.5) + Math.abs(move.to.col - 3.5);
        score += (7 - centerDist) * 0.5 + Math.random() * 0.5;
        if (score > bestScore) { bestScore = score; bestMove = move; }
    }
    if (bestMove) {
        const piece = chessBoard[bestMove.from.row][bestMove.from.col];
        chessLastMove = { from: bestMove.from, to: bestMove.to };
        
        const boardEl = document.getElementById('chessBoard');
        const fromSquare = boardEl.children[bestMove.from.row * 8 + bestMove.from.col];
        const pieceEl = fromSquare.querySelector('.piece');
        if (pieceEl) {
            pieceEl.classList.add('moving');
            setTimeout(() => pieceEl.classList.remove('moving'), 200);
        }

        chessBoard[bestMove.to.row][bestMove.to.col] = piece;
        chessBoard[bestMove.from.row][bestMove.from.col] = '';
        if (piece === 'bP' && bestMove.to.row === 7) chessBoard[bestMove.to.row][bestMove.to.col] = 'bQ';
    }
    const opponentKing = findKing('w');
    chessCheckState = opponentKing ? isInCheck('w') : false;
    chessTurn = 'w';
    chessTotalMoves++;
    renderChessBoard();
    updateChessUI();
    
    if (isCheckmate('w')) {
        chessGameOver = true;
        showChessLose('Checkmate! Computer wins.');
        renderChessBoard();
        updateChessUI();
        return;
    }
    if (isStalemate('w')) {
        chessGameOver = true;
        showChessDraw();
        renderChessBoard();
        updateChessUI();
        return;
    }
    updateChessStatus('Your turn — White!', '♔');
}

function getAllValidMoves(color) {
    const moves = [];
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
        const piece = chessBoard[r][c];
        if (piece && piece[0] === color) {
            for (const m of getValidMoves(r, c, color)) moves.push({ from: { row: r, col: c }, to: m });
        }
    }
    return moves;
}

function getValidMoves(row, col, color) {
    const piece = chessBoard[row][col];
    if (!piece || piece[0] !== color) return [];
    const type = piece[1];
    const moves = [];
    const addSlidingMoves = (directions) => {
        for (const [dr, dc] of directions) {
            let r = row + dr, c = col + dc;
            while (r >= 0 && r < 8 && c >= 0 && c < 8) {
                const target = chessBoard[r][c];
                if (target && target[0] === color) break;
                moves.push({ row: r, col: c });
                if (target) break;
                r += dr; c += dc;
            }
        }
    };
    switch (type) {
        case 'P':
            const dir = color === 'w' ? -1 : 1;
            const startRow = color === 'w' ? 6 : 1;
            if (row + dir >= 0 && row + dir < 8 && !chessBoard[row + dir][col]) {
                moves.push({ row: row + dir, col });
                if (row === startRow && !chessBoard[row + 2 * dir][col]) moves.push({ row: row + 2 * dir, col });
            }
            for (const dc of [-1, 1]) {
                const nr = row + dir, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                    const target = chessBoard[nr][nc];
                    if (target && target[0] !== color) moves.push({ row: nr, col: nc });
                }
            }
            break;
        case 'N':
            for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
                const nr = row + dr, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                    const target = chessBoard[nr][nc];
                    if (!target || target[0] !== color) moves.push({ row: nr, col: nc });
                }
            }
            break;
        case 'B': addSlidingMoves([[-1,-1],[-1,1],[1,-1],[1,1]]); break;
        case 'R': addSlidingMoves([[-1,0],[1,0],[0,-1],[0,1]]); break;
        case 'Q': addSlidingMoves([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]); break;
        case 'K':
            for (const dr of [-1,0,1]) for (const dc of [-1,0,1]) {
                if (dr === 0 && dc === 0) continue;
                const nr = row + dr, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                    const target = chessBoard[nr][nc];
                    if (!target || target[0] !== color) moves.push({ row: nr, col: nc });
                }
            }
            break;
    }
    const validMoves = [];
    for (const move of moves) {
        const tempBoard = chessBoard.map(row => [...row]);
        tempBoard[move.row][move.col] = tempBoard[row][col];
        tempBoard[row][col] = '';
        const kingPos = findKingOnBoard(tempBoard, color);
        if (kingPos && !isSquareAttacked(tempBoard, kingPos.row, kingPos.col, color === 'w' ? 'b' : 'w')) {
            validMoves.push(move);
        }
    }
    return validMoves;
}

function findKing(color) { return findKingOnBoard(chessBoard, color); }
function findKingOnBoard(board, color) {
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
        if (board[r][c] === color + 'K') return { row: r, col: c };
    }
    return null;
}
function isSquareAttacked(board, row, col, byColor) {
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece[0] === byColor) {
            const attacks = getAttacks(board, r, c, piece);
            if (attacks.some(m => m.row === row && m.col === col)) return true;
        }
    }
    return false;
}
function getAttacks(board, row, col, piece) {
    const type = piece[1], color = piece[0], attacks = [];
    const addSlidingAttacks = (directions) => {
        for (const [dr, dc] of directions) {
            let r = row + dr, c = col + dc;
            while (r >= 0 && r < 8 && c >= 0 && c < 8) {
                attacks.push({ row: r, col: c });
                if (board[r][c]) break;
                r += dr; c += dc;
            }
        }
    };
    switch (type) {
        case 'P':
            const dir = color === 'w' ? -1 : 1;
            for (const dc of [-1, 1]) {
                const nr = row + dir, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) attacks.push({ row: nr, col: nc });
            }
            break;
        case 'N':
            for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
                const nr = row + dr, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) attacks.push({ row: nr, col: nc });
            }
            break;
        case 'B': addSlidingAttacks([[-1,-1],[-1,1],[1,-1],[1,1]]); break;
        case 'R': addSlidingAttacks([[-1,0],[1,0],[0,-1],[0,1]]); break;
        case 'Q': addSlidingAttacks([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]); break;
        case 'K':
            for (const dr of [-1,0,1]) for (const dc of [-1,0,1]) {
                if (dr === 0 && dc === 0) continue;
                const nr = row + dr, nc = col + dc;
                if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) attacks.push({ row: nr, col: nc });
            }
            break;
    }
    return attacks;
}
function isInCheck(color) {
    const kingPos = findKing(color);
    if (!kingPos) return false;
    return isSquareAttacked(chessBoard, kingPos.row, kingPos.col, color === 'w' ? 'b' : 'w');
}
function isCheckmate(color) { return isInCheck(color) && getAllValidMoves(color).length === 0; }
function isStalemate(color) { return !isInCheck(color) && getAllValidMoves(color).length === 0; }

function updateChessUI() {
    const filled = chessCapturedByPlayer.length;
    document.getElementById('chessCapturedCount').textContent = Math.min(filled, 3);
    const msg = document.getElementById('chessMessage');
    if (chessPlayerWins) {
        msg.textContent = '✨ You won! Meeting unlocked! 💛';
        msg.classList.add('ready'); msg.classList.remove('check');
    } else if (chessCheckState) {
        msg.textContent = '⚠️ Check! Defend your king!';
        msg.classList.add('check'); msg.classList.remove('ready');
    } else {
        msg.textContent = `Capture ${3 - filled} more to unlock 💛`;
        msg.classList.toggle('ready', filled >= 2);
        msg.classList.remove('check');
    }
}
function updateChessStatus(msg, icon) {
    document.getElementById('chessStatus').textContent = msg;
    document.getElementById('chessTurnIcon').textContent = icon;
}
function updateCapturedDisplay() {
    const container = document.getElementById('chessCapturedPieces');
    if (!container) return;
    container.innerHTML = '';
    for (const piece of chessCapturedByPlayer) {
        const span = document.createElement('span');
        span.textContent = PIECES[piece] || piece;
        container.appendChild(span);
    }
}
function showChessWin() {
    document.getElementById('chessResult').classList.add('win');
    document.getElementById('chessResultIcon').textContent = '🏆';
    document.getElementById('chessResultTitle').textContent = '💛SWEETIE💛 YOU WIN! 🥳💛';
    document.getElementById('chessResultMessage').textContent = 'You defeated the computer! Meeting unlocked.';
    updateChessStatus('You won! 🏆', '🏆');
    document.getElementById('meetingUnlocked').classList.add('show');
    qConfetti();
    qToast('💛SWEETIE💛 You win! Meeting unlocked! 🎉💛');
    vibrate([30, 50, 30]);
    setTimeout(() => {
        if (chessPlayerWins && chessCapturedByPlayer.length >= 3) {
            qConfetti();
            qToast('Meeting time 📅💛');
            qShowScreen(6);
        }
    }, 4000);
}
function showChessLose(reason) {
    document.getElementById('chessResult').classList.remove('win');
    document.getElementById('chessResultIcon').textContent = '♚';
    document.getElementById('chessResultTitle').textContent = 'Almost! Try Again 😊';
    document.getElementById('chessResultMessage').textContent = reason || 'Computer got the better of you.';
    updateChessStatus('Computer won — retry!', '♚');
    qToast('Almost! Try again 😊');
}
function showChessDraw() {
    document.getElementById('chessResult').classList.remove('win');
    document.getElementById('chessResultIcon').textContent = '🤝';
    document.getElementById('chessResultTitle').textContent = "It's a Draw!";
    document.getElementById('chessResultMessage').textContent = 'Play again to win!';
    updateChessStatus('Draw — retry!', '🤝');
    qToast("Draw! Play again 💛");
}
function resetChessGame() {
    initChessBoard();
    document.getElementById('chessResult').classList.remove('win');
    document.getElementById('chessResultIcon').textContent = '✨';
    document.getElementById('chessResultTitle').textContent = 'Win to continue 💛';
    document.getElementById('chessResultMessage').textContent = 'Capture 3 pieces to unlock the meeting.';
    document.getElementById('meetingUnlocked').classList.remove('show');
    document.getElementById('chessCapturedPieces').innerHTML = '';
    updateChessStatus('Your turn — White!', '♔');
    updateChessUI();
    qToast('New chess game started ♟️');
}

/* =====================================================
   SAVE TO PHP
===================================================== */
async function qSaveQuiz() {
    const form = new FormData();
    form.append('save_quiz', '1');
    form.append('food_category', qSelectedFood);
    form.append('food_dish', qSelectedDish);
    form.append('roti_type', qSelectedRoti);
    form.append('street_food', qSelectedFood === 'street' ? qSelectedDish : '');
    form.append('homemade_food', qSelectedFood === 'homemade' ? qSelectedDish : '');
    form.append('custom_food', document.getElementById('customFood')?.value || '');
    form.append('icecream_company', qSelectedCompany);
    form.append('icecream_flavor', qSelectedFlavor);
    form.append('comfortable', qComfortable);
    form.append('meeting_activities', qActivities.join(', '));
    form.append('movie_category', qActivitySubOptions.movie || '');
    form.append('garden_location', qActivitySubOptions.garden || '');
    form.append('mall_choice', qActivitySubOptions.mall || '');
    form.append('sport_choice', qActivitySubOptions.sport || '');
    form.append('meeting_date', document.getElementById('qMeetingDate')?.value || '');
    form.append('meeting_time', document.getElementById('qMeetingTime')?.value || '');
    form.append('chess_won', chessPlayerWins ? '1' : '0');
    form.append('chess_captures', String(chessCapturedByPlayer.length));
    form.append('chess_moves', String(chessTotalMoves));
    try {
        const res = await fetch(window.location.href, { method: 'POST', body: form });
        const data = await res.json();
        if (data.success) console.log('✅ Saved to DB, id=' + data.id);
        else console.error('❌ Save failed:', data.message);
    } catch (e) { console.error('Save error:', e); }
}

/* =====================================================
   CONFETTI / SPARKLE / TOAST
===================================================== */
function qConfetti() {
    const syms = ['💛','✨','💖','🌸','⭐','💕','🌷'];
    for (let i = 0; i < 50; i++) {
        const p = document.createElement('div');
        p.className = 'confetti';
        p.textContent = syms[Math.floor(Math.random() * syms.length)];
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (2.5 + Math.random() * 2.5) + 's';
        p.style.animationDelay = Math.random() * 1.5 + 's';
        document.querySelector('.screen').appendChild(p);
        setTimeout(() => p.remove(), 6000);
    }
}
function qSparkle(el) {
    const rect = el.getBoundingClientRect();
    const screen = document.querySelector('.screen').getBoundingClientRect();
    const x = rect.left - screen.left + rect.width / 2;
    const y = rect.top - screen.top + rect.height / 2;
    const colors = ['#d4b8e0','#c9a9b8','#e8c8d0','#b8d4c0','#e8d4b8'];
    for (let i = 0; i < 10; i++) {
        const s = document.createElement('div');
        s.className = 'sparkle-burst';
        const a = (Math.PI * 2 * i) / 10;
        const d = 30 + Math.random() * 30;
        s.style.setProperty('--sx', Math.cos(a) * d + 'px');
        s.style.setProperty('--sy', Math.sin(a) * d + 'px');
        s.style.left = x + 'px';
        s.style.top = y + 'px';
        s.style.background = colors[i % colors.length];
        s.style.boxShadow = `0 0 15px ${s.style.background}`;
        document.querySelector('.screen').appendChild(s);
        setTimeout(() => s.remove(), 1000);
    }
}
let qToastTimer;
function qToast(msg) {
    const t = document.getElementById('qToast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(qToastTimer);
    qToastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}
function imgFallback(el, label, bg, fg) {
    el.onerror = null;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300">
        <rect width="100%" height="100%" fill="#${bg}"/>
        <text x="50%" y="50%" font-family="Arial" font-size="20" font-weight="bold"
              fill="#${fg}" text-anchor="middle" dominant-baseline="middle">${label}</text>
    </svg>`;
    el.src = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

/* =====================================================
   INIT
===================================================== */
qUpdateProgress();

(function() {
    const sel = document.getElementById('qMeetingTime');
    if (!sel) return;
    for (let h = 8; h <= 22; h++) {
        for (let m = 0; m < 60; m += 30) {
            const period = h >= 12 ? 'PM' : 'AM';
            const dh = h > 12 ? h - 12 : (h === 0 ? 12 : h);
            const dm = m === 0 ? '00' : '30';
            const opt = document.createElement('option');
            opt.value = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
            opt.textContent = `${dh}:${dm} ${period}`;
            sel.appendChild(opt);
        }
    }
})();

(function() {
    const inp = document.getElementById('qMeetingDate');
    if (!inp) return;
    const today = new Date();
    inp.min = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
})();

document.addEventListener('DOMContentLoaded', initChessBoard);
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(initChessBoard, 100);
}

setInterval(() => {
    const di = document.getElementById('dynamicIsland');
    if (!di) return;
    di.classList.add('expanded');
    setTimeout(() => di.classList.remove('expanded'), 3000);
}, 25000);

</script>

</body>
</html>